// vector - Command header

#ifndef IG_VECTOR_COMMAND_H
#define IG_VECTOR_COMMAND_H

#include "hsp3plugin_custom.h"
using namespace hpimod;

// �R�}���h�p�֐��̃v���g�^�C�v�錾
extern void VectorNew( PVal*, vartype_t, int, int, int, int, int );
extern void VectorDelete();				// �j��

extern void VectorDim();				// �����ϐ���z��ɂ���
extern void VectorClone();				// �����ϐ��̃N���[�������

extern void VectorChain();				// �A��
extern void VectorCopy();				// ����
extern int  VectorDup( void** ppResult );

extern void VectorMoving( int cmd );	// �v�f��������n
extern int  VectorMovingFunc( void** ppResult, int cmd );

extern void VectorInsert();				// �v�f�ǉ�
extern void VectorInsert1();
extern void VectorPushFront();
extern void VectorPushBack();
extern void VectorRemove();				// �v�f�폜
extern void VectorRemove1();
extern void VectorPopFront();
extern void VectorPopBack();
extern void VectorReplace();
extern int VectorInsert( void** ppResult ) ;
extern int VectorInsert1( void** ppResult ) ;
extern int VectorPushFront( void** ppResult );
extern int VectorPushBack( void** ppResult );
extern int VectorRemove( void** ppResult );
extern int VectorRemove1( void** ppResult );
extern int VectorPopFront( void** ppResult );
extern int VectorPopBack( void** ppResult );
extern int VectorReplace( void** ppResult );

extern int VectorSlice( void** ppResult );
extern int VectorSliceOut( void** ppResult );

extern int VectorMake( void** ppResult );			// as literal
extern int VectorIsNull( void** ppResult );
extern int VectorVarinfo( void** ppResult );
extern int VectorSize( void** ppResult );
extern int VectorForeachNext( void** ppResult );
extern int VectorResult( void** ppResult );
extern int VectorExpr( void** ppResult );
extern int VectorJoin( void** ppResult );
extern int VectorAt( void** ppResult );

// �V�X�e���ϐ�

// �萔
enum VARINFO {
	VARINFO_NONE = 0,
	VARINFO_FLAG = VARINFO_NONE,
	VARINFO_MODE,
	VARINFO_LEN,
	VARINFO_SIZE,
	VARINFO_PT,
	VARINFO_MASTER,
	VARINFO_MAX
};

namespace VectorCmdId {
	int const
		Move    = 0x20,
		Swap    = 0x21,
		Rotate  = 0x22,
		Reverse = 0x23;
};

#endif
