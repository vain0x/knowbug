// vector - Command code

#include <functional>

#include "vt_vector.h"
#include "cmd_vector.h"
#include "sub_vector.h"

#include "mod_makepval.h"
#include "mod_argGetter.h"
#include "mod_func_result.h"

using namespace hpimod;

static void VectorMovingImpl( CVector* self, int cmd );

//------------------------------------------------
// vector �^�̒l���󂯎��
//------------------------------------------------
CVector* code_get_vector()
{
	if ( code_getprm() <= PARAM_END ) puterror( HSPERR_NO_DEFAULT );
	if ( mpval->flag != g_vtVector ) puterror( HSPERR_TYPE_MISMATCH );
//	VectorLock_add(Vector_getPtr(mpval));
	return Vector_getPtr(mpval);
}

//------------------------------------------------
// vector �̓����ϐ����󂯎��
//------------------------------------------------
PVal* code_get_vector_inner()
{
	PVal* const pval = code_get_var();
	if ( pval->flag != g_vtVector ) puterror( HSPERR_TYPE_MISMATCH );

	PVal* const pvInner = Vector_getPValPtr( pval );
	if ( !pvInner ) puterror( HSPERR_VARIABLE_REQUIRED );
	return pvInner;
}

//------------------------------------------------
// vector �^�̒l��ԋp����
// 
// @ ���̂܂ܕԋp����ƃX�^�b�N�ɏ��B
//------------------------------------------------
int SetReffuncResult( void** ppResult, CVector* const& pTmp )
{
	CVector::Release( g_pResultVector );
	g_pResultVector = pTmp;
	CVector::AddRef( g_pResultVector );
	CVector::AddRefTmp( g_pResultVector );

	*ppResult = &g_pResultVector;
	return g_vtVector;
}

CVector* g_pResultVector = nullptr;

//#########################################################
//        ����
//#########################################################
//------------------------------------------------
// vector ���߂ł� vector �I�u�W�F�N�g�̍\�z
//------------------------------------------------
void VectorNew( PVal* pval, vartype_t vflag, int len0, int len1, int len2, int len3, int len4)
{
	exinfo->HspFunc_dim( pval, vflag, 0, len1, 0, 0, 0 );

	// �K�����̉�
	CVector*& self = Vector_getPtr(pval);
	if ( isNull(self) ) {
		self = CVector::New();
		self->AddRef();
		self->Alloc( len1 );
	}
	return;
}

//------------------------------------------------
// �j��
//------------------------------------------------
void VectorDelete()
{
	PVal* const pval = code_get_var();
	if ( pval->flag != g_vtVector ) puterror( HSPERR_TYPE_MISMATCH );

	CVector** const pData = Vector_getValptr(pval);
	CVector::Release(*pData); *pData = nullptr;
	return;
}

//------------------------------------------------
// vector �^�� dim
// 
// @prm: [ vector[idx], vartype, len1..4 ]
//------------------------------------------------
void VectorDim()
{
	PVal* const pvdat = code_get_vector_inner();	// vector
	int   const vflag = code_getdi(pvdat->flag);	// �^�^�C�v�l

	int len[5];
	for ( int i = 0; i < 4; ++ i ) {
		len[i + 1] = code_getdi(0);		// �v�f��
	}

	// �z��Ƃ��ď���������
	if ( vflag == g_vtVector ) {
		// vector �^�� VectorNew �ŏ���������
		VectorNew(pvdat, vflag, 0, len[1], len[2], len[3], len[4]);
	} else {
		exinfo->HspFunc_dim(pvdat, vflag, 0, len[1], len[2], len[3], len[4]);
	}
	return;
}

//------------------------------------------------
// vector �̓����ϐ��̃N���[�������
//------------------------------------------------
void VectorClone()
{
	PVal* const pvalSrc = code_get_vector_inner();	// �N���[����( vector )
	PVal* const pvalDst = code_getpval();			// �N���[����

	PVal_cloneVar( pvalDst, pvalSrc );
	return;
}

//#########################################################
//        �R���e�i����
//#########################################################
//------------------------------------------------
// �A��
//------------------------------------------------
void VectorChain()
{
	CVectorHolder dst = code_get_vector();
	CVectorHolder src = code_get_vector();
	dst->Chain( *src );
	return;
}

//------------------------------------------------
// ����
//------------------------------------------------
void VectorCopy()
{
	CVectorHolder dst = code_get_vector();
	CVectorHolder src = code_get_vector();

	int iBgn = code_getdi( 0 );
	int iEnd = code_getdi( src->Size() );

	if ( iBgn < 0 ) iBgn = 0;
	if ( iEnd < 0 ) iEnd = src->Size();

	dst->Clear();

	if ( src->IsValid(iBgn, iEnd) ) {
		dst->ChainWithCopy( *src, iBgn, iEnd );
	}
	return;
}

//------------------------------------------------
// ����(Duplicate)
//------------------------------------------------
int VectorDup( void** ppResult )
{
	CVector* const src = code_get_vector();
	int iBgn = code_getdi( 0 );
	int iEnd = code_getdi( src->Size() );

	if ( iBgn < 0 ) iBgn = 0;
	if ( iEnd < 0 ) iEnd = src->Size();

	if ( !src->IsValid(iBgn, iEnd) ) {
		return SetReffuncResult( ppResult, CVector::Null );

	} else {
		// PVal �̒l�𕡐����� vector ����������
		CVector* const self = Vector_newTemp();
		{
			self->ChainWithCopy( *src, iBgn, iEnd );
		}

		return SetReffuncResult( ppResult, self );
	}
}

//------------------------------------------------
// �R���e�i���쏈���e���v���[�g
//------------------------------------------------
// ���

//------------------------------------------------
// �v�f����
//------------------------------------------------
void VectorMoving( int cmd )
{
	PVal* const pval = code_get_var();
	if ( pval->flag != g_vtVector ) puterror( HSPERR_TYPE_MISMATCH );

	CVector* const src = Vector_getPtr(pval);
	if ( isNull( src ) ) puterror( HSPERR_INVALID_PARAMETER );

	VectorMovingImpl( src, cmd );
	return;
}

static void VectorMovingImpl( CVector* self, int cmd )
{
	switch ( cmd ) {
		case VectorCmdId::Move:
		{
			int const iDst = code_geti();
			int const iSrc = code_geti();
			if ( !self->IsValid(iDst) || !self->IsValid(iSrc) ) puterror( HSPERR_INVALID_PARAMETER );
			self->Move( iDst, iSrc );
			break;
		}
		case VectorCmdId::Swap:
		{
			self->Swap( code_geti(), code_geti() );		// �����͏��s��
			break;
		}
		case VectorCmdId::Rotate:
		{
			self->Rotate( code_getdi(1) );
			break;
		}
		case VectorCmdId::Reverse:
		{
			if ( !code_isNextArg() ) {
				self->Reverse();
			} else {
				int const iBgn = code_getdi( 0 );
				int const iEnd = code_getdi( self->Size() );
				if ( iBgn < 0 || !self->IsValid(iBgn, iEnd) ) puterror( HSPERR_INVALID_PARAMETER );
				self->Reverse( iBgn, iEnd );
			}
			break;
		}
	}
	return;
}

int VectorMovingFunc( void** ppResult, int cmd )
{
	CVector* const src = code_get_vector();
	if ( isNull( src ) ) puterror( HSPERR_INVALID_PARAMETER );

	// PValRef �����L���� vector ����������
	CVector* const self = Vector_newTemp();
	{
		self->Chain( *src );
		VectorMovingImpl( self, cmd );
	}

	return SetReffuncResult( ppResult, self );
}

//------------------------------------------------
// �v�f: �ǉ�, ����
// 
// @t-prm idProc: �����Ŏg���̂݁B
// @	0: Insert
// @	1: Insert1
// @	2: PushFront
// @	3: PushBack
// @	4: Remove
// @	5: Remove1
// @	6: PopFront
// @	7: PopBack
// @	8: Replace
//------------------------------------------------
template<int idProc>
static void VectorElemProcImpl( CVector* self )
{
	switch ( idProc ) {
		// ��ԃA�N�Z�X => ��Ԃ��K�v; ���� insert => �����l���X�g����� (�ȗ���)
		case 0:
		case 4:
		{
			int const iBgn = code_geti();
			int const iEnd = code_geti();
			if ( iBgn == iEnd ) break;

			if ( idProc == 0 ) {
				self->Insert( iBgn, iEnd );

				// �����l���X�g (�ȗ���)
				bool   const bReversed = (iBgn > iEnd);
				size_t const cntElems  = ( !bReversed ? iEnd - iBgn : iBgn - iEnd );
				for ( size_t i = 0; i < cntElems; ++ i ) {
					int const chk = code_getprm();
					if ( chk <= PARAM_END ) {
						if ( chk == PARAM_DEFAULT ) continue; else break;
					}
					PVal_assign( self->AtSafe( (!bReversed ? iBgn + i : iBgn - i) ), mpval->pt, mpval->flag );
				}

			} else {
				self->Remove( iBgn, iEnd );
			}
			break;
		}
		// �P��A�N�Z�X => �Y�����K�v; ���� insert1 => �����l����� (�ȗ���)
		case 1:
		case 5:
		{
			int const idx = code_geti();

			if ( idProc == 1 ) {
				PVal* const pvdat = self->Insert( idx );

				// �����l
				if ( code_getprm() > PARAM_END ) {
					PVal_assign( pvdat, mpval->pt, mpval->flag );
				}

			} else {
				self->Remove( idx );
			}
			break;
		}
		// push => �����l����� (�ȗ���)
		case 2:
		case 3:
		{
			PVal* const pvdat = (idProc == 2)
				? self->PushFront()
				: self->PushBack();

			if ( code_getprm() > PARAM_END )  {
				PVal_assign( pvdat, mpval->pt, mpval->flag );
			}
			break;
		}
		// pop
		case 6: self->PopFront(); break;
		case 7: self->PopBack();  break;

		default:
			puterror( HSPERR_UNSUPPORTED_FUNCTION );
	}

	return;
}

// ����
template<int idProc>
static void VectorElemProc()
{
	CVectorHolder self = code_get_vector();
	if ( isNull( self ) ) puterror( HSPERR_INVALID_PARAMETER );

	VectorElemProcImpl<idProc>( self );
	return;
}

void VectorInsert()    { VectorElemProc<0>(); }
void VectorInsert1()   { VectorElemProc<1>(); }
void VectorPushFront() { VectorElemProc<2>(); }
void VectorPushBack()  { VectorElemProc<3>(); }
void VectorRemove()    { VectorElemProc<4>(); }
void VectorRemove1()   { VectorElemProc<5>(); }
void VectorPopFront()  { VectorElemProc<6>(); }
void VectorPopBack()   { VectorElemProc<7>(); }

// �֐�
template<int idProc>
static int VectorElemProc( void** ppResult )
{
	CVectorHolder const src = code_get_vector();
	if ( isNull( src ) ) puterror( HSPERR_INVALID_PARAMETER );

	CVector* const self = Vector_newTemp();		// ���l�Ȉꎞ�I�u�W�F�N�g�𐶐�
	self->Chain( *src );

	VectorElemProcImpl<idProc>( self );

	return SetReffuncResult( ppResult, self );
}

int VectorInsert   ( void** ppResult ) { return VectorElemProc<0>( ppResult ); }
int VectorInsert1  ( void** ppResult ) { return VectorElemProc<1>( ppResult ); }
int VectorPushFront( void** ppResult ) { return VectorElemProc<2>( ppResult ); }
int VectorPushBack ( void** ppResult ) { return VectorElemProc<3>( ppResult ); }
int VectorRemove   ( void** ppResult ) { return VectorElemProc<4>( ppResult ); }
int VectorRemove1  ( void** ppResult ) { return VectorElemProc<5>( ppResult ); }
int VectorPopFront ( void** ppResult ) { return VectorElemProc<6>( ppResult ); }
int VectorPopBack  ( void** ppResult ) { return VectorElemProc<7>( ppResult ); }

//------------------------------------------------
// �v�f�u��
//------------------------------------------------
// ����
void VectorReplace()
{
	PVal* const pval = code_get_var();
	if ( pval->flag != g_vtVector ) puterror( HSPERR_TYPE_MISMATCH );

	CVectorHolder self = Vector_getPtr(pval);
	if ( isNull( self ) ) puterror( HSPERR_INVALID_PARAMETER );

	int const iBgn = code_getdi( 0 );
	int const iEnd = code_getdi( self->Size() );
	if ( !self->IsValid(iBgn, iEnd) ) puterror( HSPERR_INVALID_PARAMETER );

	CVectorHolder src = code_get_vector();	// null �ł�����

	self->Replace( iBgn, iEnd, src );
	return;
}

// �֐�
int VectorReplace( void** ppResult )
{
	CVectorHolder self = code_get_vector();
	if ( isNull( self ) ) puterror( HSPERR_INVALID_PARAMETER );

	int const iBgn = code_getdi( 0 );
	int const iEnd = code_getdi( self->Size() );
	CVectorHolder src = code_get_vector();	// null �ł�����

	if ( !self->IsValid(iBgn, iEnd) ) {
		return SetReffuncResult( ppResult, CVector::Null );

	} else {
		// ���l�Ȉꎞ�I�u�W�F�N�g�𐶐�����
		CVector* const result = Vector_newTemp();
		{
			if ( iBgn < iEnd ) {
				result->Chain( *self, 0, iBgn );
				if ( src ) result->Chain( *src );
				result->Chain( *self, iEnd );
			} else {
				result->Chain( *self, self->Size() - 1, iBgn );
				if ( src ) result->Chain( *src, src->Size() - 1, -1 );
				result->Chain( *self, iEnd, -1 );
			}
		}
		return SetReffuncResult( ppResult, result );
	}
}

//------------------------------------------------
// �X���C�X
//------------------------------------------------
int VectorSlice( void** ppResult )
{
	CVectorHolder src = code_get_vector();
	int iBgn = code_getdi( 0 );
	int iEnd = code_getdi( src->Size() );

	if ( iBgn < 0 ) iBgn = 0;

	if ( !src->IsValid(iBgn, iEnd) ) {
		return SetReffuncResult( ppResult, CVector::Null );

	} else {
		// PValRef �����L���� vector ����������
		CVector* const self = Vector_newTemp();
		{
			self->Chain( *src, iBgn, iEnd );
		}

		return SetReffuncResult( ppResult, self );
	}
}

//------------------------------------------------
// �X���C�X�E�A�E�g
//------------------------------------------------
int VectorSliceOut( void** ppResult )
{
	CVectorHolder src = code_get_vector();
	int iBgn = code_getdi( 0 );
	int iEnd = code_getdi( src->Size() );

	if ( iBgn < 0 ) iBgn = 0;

	if ( !src->IsValid(iBgn, iEnd) ) {
		return SetReffuncResult( ppResult, CVector::Null );

	} else {
		// PValRef �����L���� vector ����������
		CVector* const self = Vector_newTemp();
		{
			if ( iBgn < iEnd ) {
				self->Chain( *src, 0, iBgn );
				self->Chain( *src, iEnd );
			} else {
				self->Chain( *src, src->Size() - 1, iBgn );
				self->Chain( *src, iEnd, -1 );
			}
		}

		return SetReffuncResult( ppResult, self );
	}
}

//#########################################################
//        �֐�
//#########################################################
//------------------------------------------------
// ���e����������
//------------------------------------------------
int VectorMake(void** ppResult)
{
	CVector* const self = Vector_newTemp();

	while ( code_isNextArg() ) {
		int chk = code_getprm();
		assert( chk != PARAM_END && chk != PARAM_ENDSPLIT );

		PVal* const pval = self->PushBack();
		if ( chk != PARAM_DEFAULT ) {
			PVal_assign( pval, mpval->pt, mpval->flag );
		}
		// else: �����l�̂܂�
	}

	return SetReffuncResult( ppResult, self );
}

//------------------------------------------------
// null ��
//------------------------------------------------
int VectorIsNull( void** ppResult )
{
	CVector* const self = code_get_vector();
	return SetReffuncResult( ppResult, HspBool(!isNull(self)) );
}

//------------------------------------------------
// �����ϐ��̏��𓾂�
//------------------------------------------------
int VectorVarinfo(void** ppResult)
{
	PVal* const pval  = code_get_vector_inner();
	int const inftype = code_getdi(VARINFO_NONE);
	int const opt     = code_getdi(0);

	switch ( inftype ) {
		case VARINFO_FLAG:   return SetReffuncResult(ppResult, (int)pval->flag);
		case VARINFO_MODE:   return SetReffuncResult(ppResult, (int)pval->mode);
		case VARINFO_LEN:    return SetReffuncResult(ppResult, pval->len[opt + 1]);
		case VARINFO_SIZE:   return SetReffuncResult(ppResult, pval->size);
		case VARINFO_PT:     return SetReffuncResult(ppResult, (int)pval->pt);
		case VARINFO_MASTER: return SetReffuncResult(ppResult, (int)pval->master);
		default:
			puterror( HSPERR_UNSUPPORTED_FUNCTION );
			throw;
	}
}

int VectorSize( void** ppResult )
{
	CVector* const self = code_get_vector();
	size_t const size = ( isNull(self) ? 0 : self->Size() );
	return SetReffuncResult( ppResult, (int)size );
}

//------------------------------------------------
// vector �ԋp�֐�
//------------------------------------------------
static int const stc_vectorResultExprMagicNumber = 0x31EC100A;
static CVector* ref_vector_expr = CVector::Null;	// weak_ptr ���� (�Q�ƃJ�E���^�𑝌������Ȃ�)

int VectorResult( void** ppResult )
{
	ref_vector_expr = code_get_vector();

	return SetReffuncResult(ppResult, stc_vectorResultExprMagicNumber);
}

int VectorExpr( void** ppResult )
{
	ref_vector_expr = CVector::Null;		// ���S��

	// ������ VectorResult() �����s�����͂�
	if ( code_geti() != stc_vectorResultExprMagicNumber ) puterror(HSPERR_INVALID_PARAMETER);

	return SetReffuncResult( ppResult, ref_vector_expr );
}

//------------------------------------------------
// �����񌋍�(Join)
//------------------------------------------------
int VectorJoin( void** ppResult )
{
	CVectorHolder self = code_get_vector();
	char const* const splitter = code_getds( ", " );

	size_t const lenSplitter = strlen(splitter);

	// �����񉻏���
	std::function<void(CVector*, char*, int, size_t&)> impl
		= [&splitter, &lenSplitter, &impl](CVector* self, char* buf, int bufsize, size_t& idx)
	{
		CVector::Iter_t const iterBegin = self->begin();

		// foreach
		for ( auto& iter : *self ) {
			// ��؂蕶��
			if ( &iter != self->begin() ) {
				std::strncpy( &buf[idx], splitter, lenSplitter );
				idx += lenSplitter;
			}

			// �v�f�̘A��
			PVal* const pvdat = iter;

			if ( pvdat->flag == g_vtVector ) {
				// vector �̘A��
				impl( Vector_getPtr(pvdat), buf, bufsize, idx );

			} else {
				// �����񉻂��ĘA��
				char const* const pStr = (char const*)Valptr_cnvTo((PDAT*)pvdat->pt, pvdat->flag, HSPVAR_FLAG_STR);
				size_t const len  = strlen( pStr );
				std::strncpy( &buf[idx], pStr, len );
				idx += len;
			}
		}
	};

	auto const lambda = [&self, &impl](char* buf, int bufsize) {
		size_t idx = 0;				// ������̕�����̒���
		impl( self, buf, bufsize, idx );
		buf[idx ++] = '\0';
	};

	return SetReffuncResultString( ppResult, lambda );
}

//------------------------------------------------
// �Y���֐�
//------------------------------------------------
int VectorAt( void** ppResult )
{
	CVectorHolder self = code_get_vector();

	int vtype;
	if ( void* const pResult = Vector_indexRhs(&self, &vtype) ) {
		*ppResult = pResult;
		return vtype;
	} else {
		return SetReffuncResult(ppResult, self.get());
	}
}
