// vector - interface

#ifndef IG_VECTOR_INTERFACE_H
#define IG_VECTOR_INTERFACE_H

#include "hsp3plugin_custom.h"

EXPORT void WINAPI hpi_vector( HSP3TYPEINFO* info );

extern HMODULE g_hKnowbug;

#endif
