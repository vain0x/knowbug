// Vector ���̃f�[�^�N���X

#ifndef IG_CLASS_VECTOR_H
#define IG_CLASS_VECTOR_H

// todo: ��ʉ����� VWRC �ɒu��������B

#include "hsp3plugin_custom.h"

class CVector;
static bool isNull( CVector const* const src );

//	#define DBGOUT_VECTOR_ADDREF_OR_RELEASE	// AddRef, Release �� dbgout �ŕ񍐂���; mpval �ł̃J�E���^�������߂�ǂ������̂ɒ���

//------------------------------------------------
// vector �̎��̃f�[�^���� CVector* ����������N���X
// 
// @ CVector �́A�uPValRef* �̑g�ݍ��킹�ƁA���̏����v��\������B
//------------------------------------------------
class CVector
{
public:
	using Iter_t = PVal**;
	using CIter_t = PVal const* const*;

public:
	static CVector* const Null;
	static CVector* const MagicNull;

	//--------------------------------------------
	// �����o�ϐ�
	//--------------------------------------------
private:
	PVal*  mpvOwn;			// �I�[�i�[ (len �̓����Ɏg���Ă���; ���݂͖��g�p)
	PVal** mpVec;			// ���f�[�^�ւ̃|�C���^ (���ۂ� PValRef* �̔z��)
	size_t msize;
	size_t mcapa;

	mutable int mcntRefed;	// �Q�ƃJ�E���^ (0�ȉ��Ŏ��S)
	mutable int mcntTmp;	// �X�^�b�N�ɂ��Q�ƃJ�E���^

	//--------------------------------------------
	// �����o�֐�
	//--------------------------------------------
public:
	static CVector* New( PVal* pval = nullptr );

private:
	CVector( PVal* pval = nullptr );
	~CVector();
	void Free();

	static void Delete( CVector* src );

	// �R���e�i�̏��
public:
	size_t Size()     const { return msize; }
	size_t Capacity() const { return mcapa; }
	bool   Empty()    const { return msize == 0; }

	 Iter_t  begin()       { return mpVec; }
	 Iter_t    end()       { return mpVec + Size(); }
	CIter_t  begin() const { return mpVec; }
	CIter_t    end() const { return mpVec + Size(); }
	 Iter_t rbegin()       { return   end() - 1; }
	 Iter_t   rend()       { return begin() - 1; }
	CIter_t rbegin() const { return   end() - 1; }
	CIter_t   rend() const { return begin() - 1; }

	int Compare( CVector const& src ) const;
	static int Compare( CVector const* lhs, CVector const* rhs );

	// �Y��
public:
	PVal* operator[]( size_t const idx ) { return At(idx); }
	PVal* At( size_t idx );
	PVal* AtSafe( size_t idx ) const { return ( IsValid(idx) ? AtUnsafe(idx) : nullptr ); }

	bool IsValid( int    idx ) const { return ( 0 <= idx && IsValid( static_cast<size_t>(idx) ) ); }
	bool IsValid( size_t idx ) const { return (idx < Size()); }
	bool IsValid( size_t iBgn, int iEnd ) const {
		return ( static_cast<int>(iBgn) < iEnd && IsValid( iEnd - 1 ) )
			|| ( static_cast<int>(iBgn) > iEnd && IsValid( iEnd + 1, iBgn + 1 ) );
	}

private:
	PVal*& AtUnsafe( size_t idx ) const { return mpVec[idx]; }
	PVal*& AtFirst() const { assert(!Empty()); return AtUnsafe(0); }
	PVal*& AtLast()  const { assert(!Empty()); return AtUnsafe( Size() - 1 ); }

	// �������Ǘ�
public:
	void Alloc  ( size_t const newSize ) { AllocImpl( newSize, true ); }
	void Expand ( size_t const exSize  ) { Alloc( Size() + exSize ); }
	void Reserve( size_t const minCapa ) { if ( minCapa > Capacity() ) { ReserveImpl( minCapa - Capacity() ); } }

private:
	void AllocImpl  ( size_t const newSize, bool bInit = false );
	void ExpandImpl ( size_t const exSize, bool bInit = false ) { AllocImpl( Size() + exSize, bInit ); }
	void ReserveImpl( size_t const exSize );
	void SetSizeImpl( size_t const newSize );

	// �v�f�������Ǘ�
private:
	PVal* NewElem( int vflag = HSPVAR_FLAG_INT );
	void  DeleteElem( PVal* pval );

	// �v�f����
public:
	PVal* Insert( size_t idx );
	void  Insert( size_t iBgn, int iEnd );
	void  Remove( size_t idx );
	void  Remove( size_t iBgn, int iEnd );
	void  Replace( size_t iBgn, int iEnd, CVector const* src );
private:
	void  InsertImpl( size_t iBgn, size_t iEnd, bool bInit = false );
	void  RemoveImpl( size_t iBgn, size_t iEnd );
	void  ReplaceImpl( size_t iBgn, size_t iEnd, size_t cntElems );

public:
	PVal* PushFront() { return Insert(0); }
	PVal* PushBack()  { return Insert( Size() ); }

	void PopFront() { Remove( 0 ); }
	void PopBack()  { Remove( Size() - 1 ); }

	// �R���e�i�Ǘ�
public:
	void Move  ( size_t iDst, size_t iSrc );
	void Swap  ( size_t idx1, size_t idx2 );
	void Rotate( int step = 1 );
	void RotateBack( int step = 1 ) { Rotate( -step ); }
	void Reverse();
	void Reverse( size_t iBgn ) { Reverse( iBgn, Size() ); }
	void Reverse( size_t iBgn, int iEnd );

	void Clear();

	void ChainWithCopy( CVector const& src, size_t iBgn = 0 ) { return ChainImpl( src, iBgn, src.Size(), true  ); }
	void Chain        ( CVector const& src, size_t iBgn = 0 ) { return ChainImpl( src, iBgn, src.Size(), false ); }
	void CopyWithCopy ( CVector const& src, size_t iBgn = 0 ) { return CopyImpl ( src, iBgn, src.Size(), true  ); }
	void Copy         ( CVector const& src, size_t iBgn = 0 ) { return CopyImpl ( src, iBgn, src.Size(), false ); }

	void ChainWithCopy( CVector const& src, size_t iBgn, int iEnd ) { if ( src.IsValid(iBgn, iEnd) ) return ChainImpl( src, iBgn, iEnd, true  ); }
	void Chain        ( CVector const& src, size_t iBgn, int iEnd ) { if ( src.IsValid(iBgn, iEnd) ) return ChainImpl( src, iBgn, iEnd, false ); }
	void CopyWithCopy ( CVector const& src, size_t iBgn, int iEnd ) { if ( src.IsValid(iBgn, iEnd) ) return CopyImpl ( src, iBgn, iEnd, true  ); }
	void Copy         ( CVector const& src, size_t iBgn, int iEnd ) { if ( src.IsValid(iBgn, iEnd) ) return CopyImpl ( src, iBgn, iEnd, false ); }

private:
	void ChainImpl( CVector const& src, size_t iBgn, int iEnd, bool bCopyElem );
	void CopyImpl ( CVector const& src, size_t iBgn, int iEnd, bool bCopyElem ) {
		Clear(); ChainImpl( src, iBgn, iEnd, bCopyElem );
	}

private:
	void MemMove( size_t iDst, size_t iSrc, size_t cnt )
	{
		memmove( &mpVec[iDst], &mpVec[iSrc], cnt * sizeof(PVal*) );
	}

	// �Q�ƃJ�E���^
#ifdef DBGOUT_VECTOR_ADDREF_OR_RELEASE
private:
	int mid;
public:
	void AddRef()  { mcntRefed ++; dbgout("[%d] ++ �� %d", mid, mcntRefed); }
	void Release() { mcntRefed --; dbgout("[%d] -- �� %d", mid, mcntRefed); if ( mcntRefed == 0 ) Delete(this); }
	void AddRefTmp()  { dbgout("[%d] ++ �� %d <%d>", mid, ++ mcntRefed, ++ mcntTmp); }
	void ReleaseTmp() { dbgout("[%d] -- �� %d <%d>", mid, -- mcntRefed, -- mcntTmp); if ( mcntRefed == 0 ) Delete(this); }
#else
public:
	void AddRef()  { mcntRefed ++; }
	void Release() { mcntRefed --; if ( mcntRefed == 0 ) Delete(this); }
	void AddRefTmp()  { mcntTmp ++; AddRef(); }
	void ReleaseTmp() { mcntTmp --; Release(); }
#endif
	bool IsTmp() const { return mcntTmp != 0; }

	static void AddRef    ( CVector* src ) { if ( !isNull(src) ) src->AddRef(); }
	static void Release   ( CVector* src ) { if ( !isNull(src) ) src->Release(); }
	static void AddRefTmp ( CVector* src ) { if ( !isNull(src) ) src->AddRefTmp(); }
	static void ReleaseTmp( CVector* src ) { if ( !isNull(src) ) src->ReleaseTmp(); }

private:
	CVector( CVector const& src );
	CVector& operator =(CVector const& src );
};

//------------------------------------------------
// �}�N���I�֐�
//------------------------------------------------
static bool isNull( CVector const* const src )
{
	return ( src == CVector::MagicNull || src == CVector::Null );
}
//*
//------------------------------------------------
// �����Ƃ��Ď󂯎���� CVector* �����L����N���X
// 
// @ �ꎞ�ϐ��ɐ������ꂽ vector �̎��Ɉ���������ꍇ�A
// @	mpval �����L���������� vector �����ł��邽�߁A
// @	mpval �ɑ����ă��[�J���� vector �����L����B
//------------------------------------------------
class CVectorHolder
{
private:
	CVector* mpInst;

public:
	CVectorHolder( CVector* inst )
		: mpInst(inst)
	{
		CVector::AddRef(mpInst);
	}
	~CVectorHolder()
	{
		CVector::Release( mpInst );
	}

	CVector* get() { return mpInst; }
	CVector const* get() const { return mpInst; }

	operator CVector*() { return mpInst; }
	operator CVector const*() const { return mpInst; }
	CVector* operator ->() { return mpInst; }
	CVector const* operator ->() const { return mpInst; }

	CVector* const* operator&() const { return &mpInst; }

private:
	CVectorHolder();
	CVectorHolder( CVectorHolder const& );
	CVectorHolder& operator =( CVectorHolder& );
};
//*/
#endif
