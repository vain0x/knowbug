/*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
 |
 *		hsp plugin interface (vector)
 |
 *				author uedai (from 2011 07/18(Mon))
 |
.*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*/

#include "iface_vector.h"
#include "vt_vector.h"
#include "cmd_vector.h"
#include "sub_vector.h"

#include "mod_varutil.h"
#include "mod_func_result.h"

// �֐��錾
static int    cmdfunc( int cmd );
static void* reffunc( int* type_res, int cmd );
static int   termfunc( int option );

static int   ProcSttmCmd( int cmd );
static int   ProcFuncCmd( int cmd, void** ppResult );
static int ProcSysvarCmd( int cmd, void** ppResult );

//##########################################################
//        HPI����
//##########################################################
//------------------------------------------------
// HPI�o�^�֐�
//------------------------------------------------
EXPORT void WINAPI hpi_vector( HSP3TYPEINFO* info )
{
	hsp3sdk_init( info );			// SDK�̏�����(�ŏ��ɍs�Ȃ��ĉ�����)
	
	HSPVAR_COREFUNC corefunc = HspVarVector_Init;
	registvar(-1, corefunc);		// �V�K�^��ǉ�
	
	info->cmdfunc  = cmdfunc;		// ���s�֐�(cmdfunc)�̓o�^
	info->reffunc  = reffunc;		// �Q�Ɗ֐�(reffunc)�̓o�^
	info->termfunc = termfunc;		// �I���֐�(termfunc)�̓o�^
	
	return;
}

//------------------------------------------------
// ���߃R�}���h
//------------------------------------------------
static int cmdfunc( int cmd )
{
	code_next();
	return ProcSttmCmd( cmd );
}

//------------------------------------------------
// �֐��R�}���h
//------------------------------------------------
static void* reffunc( int* type_res, int cmd )
{
	void* pResult = NULL;
	
	// '('�Ŏn�܂邩�𒲂ׂ�
	if (  *type != TYPE_MARK || *val != '(' ) {
		
		*type_res = ProcSysvarCmd( cmd, &pResult );
		
	} else {
		code_next();
		
		// �R�}���h����
		*type_res = ProcFuncCmd( cmd, &pResult );
		
		// ')'�ŏI��邩�𒲂ׂ�
		if (  *type != TYPE_MARK || *val != ')' ) puterror( HSPERR_INVALID_FUNCPARAM );
		code_next();
	}
	
	return pResult;
}

//------------------------------------------------
// �I����
//------------------------------------------------
static int termfunc( int option )
{
	if ( VectorLock_size() != 0 ) VectorLock_release();
	return 0;
}

//##########################################################
//        �R�}���h����
//##########################################################
//------------------------------------------------
// ����
//------------------------------------------------
static int ProcSttmCmd( int cmd )
{
	switch ( cmd ) {
		case 0x000: dimtypeEx( g_vtVector, VectorNew ); break;
		case 0x001: VectorDelete(); break;
		case 0x002: VectorChain();  break;
		case 0x00F: VectorLock_release(); break;	// �㌩�I��
		
		case 0x010: VectorDim();   break;
		case 0x011: VectorClone(); break;
		
		case 0x013: VectorInsert();    break;
		case 0x014: VectorPushFront(); break;
		case 0x015: VectorPushBack();  break;
		case 0x016: VectorRemove();    break;
		case 0x017: VectorPopFront();  break;
		case 0x018: VectorPopBack();   break;
			
		case 0x020:
		case 0x021:
		case 0x022:
		case 0x023: VectorMoving( cmd ); break;
		
		default:
			puterror( HSPERR_UNSUPPORTED_FUNCTION );
	}
	
	return RUNMODE_RUN;
}

//------------------------------------------------
// �֐�
//------------------------------------------------
static int ProcFuncCmd( int cmd, void** ppResult )
{
	switch ( cmd ) {
		case 0x000: return VectorMake( ppResult );
		
		case 0x012:
			VectorClone();
			return SetReffuncResult( ppResult, 0 );
		
		case 0x020:
		case 0x021:
		case 0x022:
		case 0x023: return VectorMovingFunc( ppResult, cmd );
		
		case 0x100:	return VectorVarinfo( ppResult );
		case 0x101:	return VectorSize( ppResult );
		case 0x102: return VectorDup( ppResult );
		case 0x103: return VectorSlice( ppResult );
		case 0x104: return VectorResult( ppResult );
		case 0x105: return VectorExpr( ppResult );
		case 0x106: return VectorJoin( ppResult );
			
		default:
			puterror( HSPERR_UNSUPPORTED_FUNCTION );
	}
	return 0;
}

//------------------------------------------------
// �V�X�e���ϐ�
//------------------------------------------------
static int ProcSysvarCmd( int cmd, void** ppResult )
{
	switch ( cmd ) {
		case 0x000: return SetReffuncResult( ppResult, g_vtVector );
		
		case 0x200: return SetReffuncResult( ppResult, CVector::Null, g_vtVector );	// VectorNull
		
		default:
			puterror( HSPERR_UNSUPPORTED_FUNCTION );
	}
	return 0;
}
