// vector - SubCommand code

#include "iface_vector.h"
#include "sub_vector.h"
#include "vt_vector.h"

#include "mod_makepval.h"

//##########################################################
//        �����E�j��
//##########################################################
//------------------------------------------------
// �ꎞ�I�u�W�F�N�g�̐���
// 
// @ �㌩���Ԃ��I������ƁA�����I�Ɏ��S����B
//------------------------------------------------
CVector* Vector_newTemp()
{
	CVector* self = CVector::New();
	return VectorLock_add( self );
}

//##########################################################
//        Vector �^�ϐ��̑���E�擾
//##########################################################
//------------------------------------------------
// �����ϐ��̎擾
// 
// @ �{�̂��Q�Ƃ���Ă���Ƃ��� null ��Ԃ��B
//------------------------------------------------
PVal* Vector_getPValPtr( PVal* pval )
{
	if ( pval->arraycnt == 0 ) return NULL;
	return Vector_getPValPtr( pval, pval->offset );
}

//------------------------------------------------
// �����ϐ��̎擾
//------------------------------------------------
PVal* Vector_getPValPtr( PVal* pval, int idx )
{
	return Vector_getPtr(pval)->At( idx );
}

//------------------------------------------------
// �����ϐ��̎��̃|�C���^���擾
//------------------------------------------------
void* Vector_getRealPtr( PVal* pval )
{
	PVal* pvdat = Vector_getPValPtr( pval );
	if ( !pvdat ) return NULL;
	
	return GetHvp( pvdat->flag )->GetPtr( pvdat );
}

//------------------------------------------------
// ���̂ւ̎Q��
//------------------------------------------------
CVector*& Vector_getPtr(PVal* pval)
{
	return *(CVector**)(&pval->master);
}

//------------------------------------------------
// ���̃|�C���^���擾
//------------------------------------------------
CVector** Vector_getValptr( PVal* pval )
{
	return (CVector**)(&pval->master);
}

//------------------------------------------------
// ����
//------------------------------------------------
void Vector_copy( PVal* pval, const CVector* src )
{
	// �^���قȂ� => ���ӂ����������� (���X�̃f�[�^�͏���)
	if ( pval->flag != g_vtVector ) {
		exinfo->HspFunc_dim( pval, g_vtVector, 0, 1, 0, 0, 0 );
	}
	
	CVector** pDst = Vector_getValptr( pval );

	CVector::Release( *pDst );
	(*pDst) = CVector::New( pval );			// �V���� CVector �𐶐�����
	(*pDst)->AddRef();
	(*pDst)->Chain( *src );
	return;
}

//------------------------------------------------
// �Q�Ƌ��L
//------------------------------------------------
void Vector_share( PVal* pval, CVector* src )
{
	CVector** pDst = Vector_getValptr(pval);
	if ( src == *pDst ) return;
	
	CVector::Release(*pDst);
	
	(*pDst) = src;
	
	CVector::AddRef(*pDst);
	return;
}

//##########################################################
//        �㌩
//##########################################################
#include <vector>
static std::vector<CVector*> stt_vector_lock;
static int stt_cntLocked;

CVector* VectorLock_add( CVector* pVec )
{
	if ( isNull(pVec) ) return CVector::Null;
	
	// �㌩����
	CVector::AddRef( pVec );
	stt_vector_lock.push_back( pVec );
	stt_cntLocked ++;
	return pVec;
}

int VectorLock_size()
{
	return stt_cntLocked;
}

void VectorLock_release()
{
	if ( stt_cntLocked == 0 ) return;
	stt_cntLocked = 0;
	
	// �S�ĉ������
	for each ( auto iter in stt_vector_lock ) {
		CVector::Release( iter );
	}
	
	stt_vector_lock.clear();
	return;
}
