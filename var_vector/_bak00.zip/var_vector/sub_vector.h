// multi - SubCommand header

#ifndef IG_VECTOR_COMMAND_SUB_H
#define IG_VECTOR_COMMAND_SUB_H

#include "CVector.h"
#include "hsp3plugin_custom.h"

// �֐��錾
extern CVector* Vector_newTemp();

extern PVal* Vector_getPValPtr( PVal* pval );
extern PVal* Vector_getPValPtr( PVal* pval, int idx );
extern void* Vector_getRealPtr( PVal* pval );
extern CVector*& Vector_getPtr( PVal* pval );
extern CVector** Vector_getValptr( PVal* pval );

extern void Vector_copy ( PVal* pval, const CVector* src );
extern void Vector_share( PVal* pval, CVector* src );
extern void Vector_free ( PVal* pval );

// �㌩
extern CVector* VectorLock_add( CVector* pVec );
extern int  VectorLock_size();
extern void VectorLock_release();

#endif
