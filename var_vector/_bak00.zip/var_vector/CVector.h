// Vector ���̃f�[�^�N���X

#ifndef IG_CLASS_VECTOR_H
#define IG_CLASS_VECTOR_H

#include "hsp3plugin_custom.h"

class CVector;
static bool isNull( const CVector* const src );

//	#define DBGOUT_VECTOR_ADDREF_OR_RELEASE	// AddRef, Release �� dbgout �ŕ񍐂���; mpval �ł̃J�E���^�������߂�ǂ������̂ɒ���

//------------------------------------------------
// vector �̎��̃f�[�^���� CVector* ����������N���X
// 
// @ CVector �́A�uPValRef* �̑g�ݍ��킹�ƁA���̏����v��\������B
//------------------------------------------------
class CVector
{
public:
	typedef PVal** Iter_t;
	typedef const PVal* const * CIter_t;
	
public:
	static CVector* const Null;
	static CVector* const MagicNull;
	
	//--------------------------------------------
	// �����o�ϐ�
	//--------------------------------------------
private:
	PVal*  mpvOwn;			// �I�[�i�[ (���݂͖��g�p)
	PVal** mpVec;			// ���f�[�^�ւ̃|�C���^ (���ۂ� PValRef* �̔z��)
	size_t msize;
	size_t mcapa;
	mutable int mcntRefed;	// �Q�ƃJ�E���^ (0�ȉ��Ŏ��S)
	
	//--------------------------------------------
	// �����o�֐�
	//--------------------------------------------
public:
	static CVector* New( PVal* pval = NULL ) { return new CVector( pval ); }
	
private:
	CVector( PVal* pval = NULL );
	~CVector();
	void Free();
	
	static void Delete( CVector* src ) { delete src; }
	
	// �R���e�i�̏��
public:
	size_t Size()     const { return msize; }
	size_t Capacity() const { return mcapa; }
	bool   Empty()    const { return msize == 0; }
	
	 Iter_t  begin()       { return mpVec; }
	 Iter_t    end()       { return mpVec + Size(); }
	CIter_t  begin() const { return mpVec; }
	CIter_t    end() const { return mpVec + Size(); }
	 Iter_t rbegin()       { return   end() - 1; }
	 Iter_t   rend()       { return begin() - 1; }
	CIter_t rbegin() const { return   end() - 1; }
	CIter_t   rend() const { return begin() - 1; }
	
	int Compare( const CVector& src ) const;
	static int Compare( const CVector* lhs, const CVector* rhs );
	
	// �Y��
public:
	PVal* operator[]( const size_t idx ) { return At(idx); }
	PVal* At( size_t idx );
	
	bool IsValid( int    idx ) const { return ( 0 <= idx && IsValid((size_t)idx) ); }
	bool IsValid( size_t idx ) const { return (idx < Size()); }
	bool IsValid( size_t iBgn, size_t iEnd ) const { return (iBgn < iEnd && IsValid(iEnd - 1) ); }
	
private:
	PVal*& AtSafe( const size_t idx ) const { return mpVec[idx]; }
	PVal*& AtFirst() const { return AtSafe(0); }
	PVal*& AtLast()  const { return AtSafe( Size() - 1 ); }
	
	// �������Ǘ�
public:
	void Alloc  ( const size_t newSize ) { AllocImpl( newSize, true ); }
	void Expand ( const size_t exSize  ) { Alloc( Size() + exSize ); }
	void Reserve( const size_t minCapa ) { if ( minCapa > Capacity() ) { ReserveImpl( minCapa - Capacity() ); } }
	
private:
	void AllocImpl  ( const size_t newSize, bool bInit = false );
	void ExpandImpl ( const size_t exSize ) { AllocImpl( Size() + exSize ); }
	void ReserveImpl( const size_t exSize );
	void SetSizeImpl( const size_t newSize );
	
	// �v�f�������Ǘ�
private:
	PVal* NewElem( int vflag = HSPVAR_FLAG_INT );
	void  DeleteElem( PVal* pval );
	
	// �v�f����
public:
	PVal* Insert( size_t idx );
	void  Remove( size_t idx );
	
	PVal* PushFront() { return Insert(0); }
	PVal* PushBack()  { return Insert( Size() ); }

	void PopFront() { Remove( 0 ); }
	void PopBack()  { Remove( Size() - 1 ); }
	
	// �R���e�i�Ǘ�
public:
	void Move  ( size_t iDst, size_t iSrc );
	void Swap  ( size_t idx1, size_t idx2 );
	void Rotate( int step = 1 );
	void RotateBack( int step = 1 ) { Rotate( -step ); }
	void Reverse();
	void Reverse( size_t iBgn = 0 ) { Reverse( iBgn, Size() ); }
	void Reverse( size_t iBgn, size_t iEnd );
	
	void Clear();
	
	void ChainWithCopy( const CVector& src, size_t iBgn = 0 ) { ChainWithCopy( src, iBgn, src.Size() ); }
	void Chain        ( const CVector& src, size_t iBgn = 0 ) { Chain        ( src, iBgn, src.Size() ); }
	void CopyWithCopy ( const CVector& src, size_t iBgn = 0 ) { CopyWithCopy ( src, iBgn, src.Size() ); }
	void Copy         ( const CVector& src, size_t iBgn = 0 ) { Copy         ( src, iBgn, src.Size() ); }
	
	void ChainWithCopy( const CVector& src, size_t iBgn, size_t iEnd ) { return ChainImpl( src, iBgn, iEnd, true  ); }
	void Chain        ( const CVector& src, size_t iBgn, size_t iEnd ) { return ChainImpl( src, iBgn, iEnd, false ); }
	void CopyWithCopy ( const CVector& src, size_t iBgn, size_t iEnd ) { return CopyImpl ( src, iBgn, iEnd, true  ); }
	void Copy         ( const CVector& src, size_t iBgn, size_t iEnd ) { return CopyImpl ( src, iBgn, iEnd, false ); }
	
private:
	void ChainImpl( const CVector& src, size_t iBgn, size_t iEnd, bool bCopyElem );
	void CopyImpl ( const CVector& src, size_t iBgn, size_t iEnd, bool bCopyElem ) {
		Clear(); ChainImpl( src, iBgn, iEnd, bCopyElem );
	}
	
private:
	void MemMove( size_t iDst, size_t iSrc, size_t cnt )
	{
		memmove( &mpVec[iDst], &mpVec[iSrc], cnt * sizeof(PVal*) );
	}
	
	// �Q�ƃJ�E���^
#ifdef DBGOUT_VECTOR_ADDREF_OR_RELEASE
private:
	int mid;
public:
	void AddRef()  { mcntRefed ++; dbgout("[%d] ++ �� %d", mid, mcntRefed); }
	void Release() { mcntRefed --; dbgout("[%d] -- �� %d", mid, mcntRefed); if ( mcntRefed == 0 ) Delete(this); }
#else
public:
	void AddRef()  { mcntRefed ++; }
	void Release() { mcntRefed --; if ( mcntRefed == 0 ) Delete(this); }
#endif
	
	static void AddRef ( CVector* src ) { if ( !isNull(src) ) src->AddRef(); }
	static void Release( CVector* src ) { if ( !isNull(src) ) src->Release(); }
	
private:
	CVector( const CVector& src );
	CVector& operator =(const CVector& src );
};

//------------------------------------------------
// �}�N���I�֐�
//------------------------------------------------
static bool isNull( const CVector* const src )
{
	return ( src == CVector::MagicNull || src == CVector::Null );
}

#endif
