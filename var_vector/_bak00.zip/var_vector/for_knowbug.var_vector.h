// header for knowbug

#ifndef IG_VECTOR_FOR_KNOWBUG_H
#define IG_VECTOR_FOR_KNOWBUG_H

class CVector;

typedef PVal** (*GetVectorList_t)( const CVector*, int* );		// HspVarProc::user

#endif
