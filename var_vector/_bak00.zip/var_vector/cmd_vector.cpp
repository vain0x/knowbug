// vector - Command code

#include <assert.h>

#include "vt_vector.h"
#include "cmd_vector.h"
#include "sub_vector.h"

#include "mod_makepval.h"
#include "mod_argGetter.h"
#include "mod_func_result.h"

static void VectorMovingImpl( CVector* self, int cmd );

//------------------------------------------------
// vector �^�̒l���󂯎��
//------------------------------------------------
CVector* code_get_vector()
{
	if ( code_getprm() <= PARAM_END ) puterror( HSPERR_NO_DEFAULT );
	if ( mpval->flag != g_vtVector ) puterror( HSPERR_TYPE_MISMATCH );
//	VectorLock_add(Vector_getPtr(mpval));
	return Vector_getPtr(mpval);
}

//#########################################################
//        ����
//#########################################################
//------------------------------------------------
// vector ���߂ł� vector �I�u�W�F�N�g�̍\�z
//------------------------------------------------
void VectorNew( PVal* pval, vartype_t vflag, int len0, int len1, int len2, int len3, int len4)
{
	exinfo->HspFunc_dim( pval, vflag, 0, len1, 0, 0, 0 );
	
	// �K�����̉�
	CVector*& self = Vector_getPtr(pval);
	if ( isNull(self) ) {
		self = CVector::New();
		self->Alloc( len1 );
	}
	return;
}

//------------------------------------------------
// �j��
//------------------------------------------------
void VectorDelete()
{
	PVal* pval = code_get_var();
	if ( pval->flag != g_vtVector ) puterror( HSPERR_TYPE_MISMATCH );
	
	CVector** pData = Vector_getValptr(pval);
	CVector::Release(*pData); *pData = NULL;
	return;
}

//------------------------------------------------
// �A��
//------------------------------------------------
void VectorChain()
{
	CVector* dst = code_get_vector();
	CVector* src = code_get_vector();
	dst->Chain( *src );
	return;
}

//------------------------------------------------
// �v�f: �ǉ�, ����
//------------------------------------------------
static void VectorElemProc( int id )
{
	PVal* pval = code_get_var();
	if ( pval->flag != g_vtVector ) puterror( HSPERR_TYPE_MISMATCH );
	
	CVector* self = Vector_getPtr(pval);
	if ( isNull( self ) ) puterror( HSPERR_INVALID_PARAMETER );
	
	PVal* pvdat = NULL;
	
	switch ( id ) {
		case 0: pvdat = self->Insert( pval->offset ); break;
		case 1: pvdat = self->PushFront(); break;
		case 2: pvdat = self->PushBack(); break;
		
		case 3: self->Remove( pval->offset ); break;
		case 4: self->PopFront(); break;
		case 5: self->PopBack(); break;
		
		default:
			puterror( HSPERR_UNSUPPORTED_FUNCTION );
	}
	
	// (�ǉ�): �v�f������������ (�ȗ���)
	if ( pvdat != NULL ) {
		if ( code_getprm() > PARAM_END ) {
			PVal_assign( pvdat, mpval->pt, mpval->flag );
		}
	}
	
	return;
}

void VectorInsert()    { VectorElemProc( 0 ); }
void VectorPushFront() { VectorElemProc( 1 ); }
void VectorPushBack()  { VectorElemProc( 2 ); }
void VectorRemove()    { VectorElemProc( 3 ); }
void VectorPopFront()  { VectorElemProc( 4 ); }
void VectorPopBack()   { VectorElemProc( 5 ); }

//------------------------------------------------
// �v�f����
//------------------------------------------------
void VectorMoving( int cmd )
{
	PVal* pval = code_get_var();
	if ( pval->flag != g_vtVector ) puterror( HSPERR_TYPE_MISMATCH );
	
	CVector* src = Vector_getPtr(pval);
	if ( isNull( src ) ) puterror( HSPERR_INVALID_PARAMETER );
	
	CVector* self = Vector_newTemp();
	self->Chain( *src );
	VectorMovingImpl( self, cmd );
	
	Vector_share( pval, self );		// �V���� Vector ��ݒ肷��
	return;
}

static void VectorMovingImpl( CVector* self, int cmd )
{
	switch ( cmd ) {
		case 0x020:
		{
			int iDst = code_geti();
			int iSrc = code_geti();
			self->Move( iDst, iSrc );
			break;
		}
		case 0x021:
		{
			self->Swap( code_geti(), code_geti() );		// �����͏��s��
			break;
		}
		case 0x022:
		{
			self->Rotate( code_getdi(1) );
			break;
		}
		case 0x023:
		{
			size_t const len = self->Size();
			size_t iBgn = code_getdi( 0 );
			size_t iEnd = code_getdi( len );
			self->Reverse( (iBgn > 0 ? iBgn : 0), (iEnd <= len ? iEnd : len) );
			break;
		}
	}
	return;
}

//------------------------------------------------
// vector �^�� dim
// 
// @prm: [ vector[idx], vartype, len1..4 ]
//------------------------------------------------
void VectorDim()
{
	PVal* pval;
	PVal* pvdat;
	int vflag, len[5];
	
	pval  = code_get_var();				// vector
	pvdat = Vector_getPValPtr(pval);
	vflag = code_getdi(pvdat->flag);	// �^�^�C�v�l
	
	for ( int i = 0; i < 4; ++ i ) {
		len[i + 1] = code_getdi(0);		// �v�f��
	}
	
	// �z��Ƃ��ď���������
	( (vflag == g_vtVector) ? VectorNew : exinfo->HspFunc_dim )		// vector �^�� VectorNew �ŏ���������
		( pvdat, vflag, 0, len[1], len[2], len[3], len[4] );
	
	return;
}

//------------------------------------------------
// vector �̓����ϐ��̃N���[�������
//------------------------------------------------
void VectorClone()
{
	PVal* pval  = code_getpval();			// �N���[����
	PVal* pvVec = code_get_var();			// �N���[����( vector )
	PVal* pvdat = Vector_getPValPtr(pvVec);
	
	PVal_clone( pval, pvdat, pvdat->offset );
	return;
}

/*
//------------------------------------------------
// VectorForeach ����������
//------------------------------------------------
void VectorForeachInit()
{
	CVector* self = code_get_vector();
	CVector::MapIter_t it = self->begin();
	
	//
}
//*/

//#########################################################
//        �֐�
//#########################################################
//------------------------------------------------
// ���e����������
//------------------------------------------------
int VectorMake(void** ppResult)
{
	CVector* self = Vector_newTemp();	// �ꎞ�I�u�W�F�N�g; ����� mpval �ɏ��L����邽�߁A�Q�ƃJ�E���^ 0 �Ő���
	
	while ( code_isNextArg() ) {
		int chk = code_getprm();
		assert( chk != PARAM_END && chk != PARAM_ENDSPLIT );
		
		PVal* pval = self->PushBack();
		if ( chk != PARAM_DEFAULT ) {		// �ȗ� => �����l�̂܂�
			PVal_assign( pval, mpval->pt, mpval->flag );	// ����
		}
	}
	
	return SetReffuncResult( ppResult, self, g_vtVector );
}

//------------------------------------------------
// �����ϐ��̏��𓾂�
//------------------------------------------------
int VectorVarinfo(void** ppResult)
{
	PVal* pval;
	PVal* pvdat;
	int inftype, opt, retflag = HSPVAR_FLAG_INT;
	
	pval    = code_get_var();
	inftype = code_getdi(VARINFO_NONE);
	opt     = code_getdi(0);
	pvdat   = Vector_getPValPtr(pval);
	
	switch ( inftype ) {
		case VARINFO_FLAG:   return SetReffuncResult( ppResult, (int)pvdat->flag );
		case VARINFO_MODE:   return SetReffuncResult( ppResult, (int)pvdat->mode );
		case VARINFO_LEN:    return SetReffuncResult( ppResult, pvdat->len[opt + 1] );
		case VARINFO_SIZE:   return SetReffuncResult( ppResult, pvdat->size );
		case VARINFO_PT:     return SetReffuncResult( ppResult, (int)(exinfo->HspFunc_getproc(pvdat->flag))->GetPtr(pvdat) );
		case VARINFO_MASTER: return SetReffuncResult( ppResult, (int)pvdat->master );
		default:
			puterror( HSPERR_UNSUPPORTED_FUNCTION );
			throw;
	}
}

int VectorSize( void** ppResult )
{
	CVector* self = code_get_vector();
	size_t size = ( isNull(self) ? 0 : self->Size() );
	return SetReffuncResult( ppResult, (int)size );
}

//------------------------------------------------
// �v�f����
//------------------------------------------------
int VectorMovingFunc( void** ppResult, int cmd )
{
	CVector* src = code_get_vector();
	if ( isNull( src ) ) puterror( HSPERR_INVALID_PARAMETER );
	
	// PValRef �����L���� vector ����������
	CVector* self = Vector_newTemp();
	{
		self->Chain( *src );
		VectorMovingImpl( self, cmd );
	}
	
	return SetReffuncResult( ppResult, self, g_vtVector );
}

//------------------------------------------------
// ����(Duplicate)
//------------------------------------------------
int VectorDup( void** ppResult )
{
	CVector* src = code_get_vector();
	int iBgn = code_getdi( 0 );
	int iEnd = code_getdi( src->Size() );
	
	if ( iBgn < 0 ) iBgn = 0;
	if ( iEnd < 0 ) iEnd = src->Size();
	
	if ( iBgn >= iEnd || iBgn >= (int)src->Size() ) {
		return SetReffuncResult( ppResult, CVector::Null, g_vtVector );
		
	} else {
		// PVal �̒l�𕡐����� vector ����������
		CVector* self = Vector_newTemp();
		{
			self->ChainWithCopy( *src, iBgn, iEnd );
		}
		
		return SetReffuncResult( ppResult, self, g_vtVector );
	}
}

//------------------------------------------------
// �X���C�X
//------------------------------------------------
int VectorSlice( void** ppResult )
{
	CVector* src = code_get_vector();
	int iBgn = code_getdi( 0 );
	int iEnd = code_getdi( src->Size() );
	
	if ( iBgn < 0 ) iBgn = 0;
	if ( iEnd < 0 ) iEnd = src->Size();
	
	if ( !src->IsValid(iBgn, iEnd) ) {
		return SetReffuncResult( ppResult, CVector::Null, g_vtVector );
		
	} else {
		// PValRef �����L���� vector ����������
		CVector* self = Vector_newTemp();
		{
			self->Chain( *src, iBgn, iEnd );
		}
		
		return SetReffuncResult( ppResult, self, g_vtVector );
	}
}

//------------------------------------------------
// vector �ԋp�֐�
//------------------------------------------------
static CVector* ref_vector_expr = NULL;

int VectorResult( void** ppResult )
{
	ref_vector_expr = code_get_vector();
	
	return SetReffuncResult( ppResult, 0 );		// ���ł�����
}

int VectorExpr( void** ppResult )
{
	ref_vector_expr = CVector::Null;		// ���S��
	
	code_getprm();		// ���ł����� (������ VectorResult() �����s�����͂�)
	
	return SetReffuncResult( ppResult, ref_vector_expr, g_vtVector );
}

//------------------------------------------------
// �����񌋍�(Join)
//------------------------------------------------
static void VectorJoinImpl( CVector* self, const char* splitter, const size_t lenSplitter, size_t& idx );

int VectorJoin( void** ppResult )
{
	CVector*    self     = code_get_vector();
	const char* splitter = code_gets();
	
	const size_t lenSplitter = strlen(splitter);
	
	size_t idx = 0;			// ������̕�����̒���
	VectorJoinImpl( self, splitter, strlen(splitter), idx );
	
	hpimod::stt_result_string[idx] = '\0';
	idx ++;
	
	return SetReffuncResultString( ppResult );		// �������Ԃ�
}

static void VectorJoinImpl( CVector* self, const char* splitter, const size_t lenSplitter, size_t& idx )
{
	CVector::Iter_t const iterBegin = self->begin();
	
	// foreach
	for ( CVector::Iter_t iter = iterBegin; iter != self->end(); ++ iter ) {
		// ��؂蕶��
		if ( iter != iterBegin ) {
			strncpy( &hpimod::stt_result_string[idx], splitter, lenSplitter );
			idx += lenSplitter;
		}
		
		// �v�f�̘A��
		PVal* pvdat = *iter;
		
		if ( pvdat->flag == g_vtVector ) {
			// vector �̘A��
			VectorJoinImpl( Vector_getPtr(pvdat), splitter, lenSplitter, idx );
			
		} else {
			// �����񉻂��ĘA��
			const char*  pStr = (const char*)Valptr_cnvTo((PDAT*)pvdat->pt, pvdat->flag, HSPVAR_FLAG_STR);
			const size_t len  = strlen( pStr );
			strncpy( &hpimod::stt_result_string[idx], pStr, len );
			idx += len;
		}
	}
	
	return;
}
