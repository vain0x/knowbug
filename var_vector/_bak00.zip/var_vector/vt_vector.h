// vector - VarProc header

#ifndef IG_VECTOR_VARPROC_H
#define IG_VECTOR_VARPROC_H

#include "CVector.h"

// �O���[�o���ϐ��̐錾
extern short g_vtVector;
extern HspVarProc* g_pHvpVector;

// �֐��̐錾
extern void HspVarVector_Init( HspVarProc* p );
extern CVector* code_get_vector();

// �萔

// �}�N��

// ��`
namespace VtVector
{
	typedef CVector* value_t;
	typedef value_t* valptr_t;		// �� PDAT*
	const int basesize = sizeof(value_t);
}

#endif
