// VarTree

#ifndef IG_CLASS_VAR_TREE_H
#define IG_CLASS_VAR_TREE_H

#include <string>
#include <list>
#include <vector>
#include <map>
#include <iterator>

//##############################################################################
//                �錾�� : CVarTree
//##############################################################################
class CVarTree
{
	//********************************************
	//    �^�錾
	//********************************************
public:
	//--------------------------------------------
	// �����q
	//--------------------------------------------
	class iterator;
	friend class iterator;
	
	enum NodeType
	{
		NodeType_Module = 0,
		NodeType_Var
	};
	
private:
	typedef std::list<std::string>              StringList_t;
	typedef std::map<std::string, StringList_t> ModuleList_t;
	typedef std::map<std::string, CVarTree>     Children_t;
	
	typedef StringList_t::iterator StringListIter_t;
	typedef ModuleList_t::iterator ModuleListIter_t;
	typedef Children_t::iterator   ChildrenIter_t;
	
	enum PushPos
	{
		PushPos_Back  = 0,
		PushPos_Front = 1
	};
	
	//********************************************
	//    �����o�ϐ�
	//********************************************
private:
	NodeType    mType;
	std::string mName;
	
	Children_t *mpChildren;
	
public:
	static std::string AreaName_Global;
	
	//********************************************
	//    �����o�֐�
	//********************************************
public:
	CVarTree( const std::string& name, NodeType type );
	CVarTree( const CVarTree& src );
	~CVarTree();
	
	// ���
	NodeType           getType( void ) const { return mType; }
	const std::string& getName( void ) const { return mName; }
	
	// �v�f�̒ǉ�
	void push_child ( const char *name, NodeType type );
	void push_var   ( const char *name ) { push_child( name, NodeType_Var ); }
	void push_module( const char *name ) { getChildModule( name ); }
	
	// �����q�̐���
	iterator begin(void) const;
	iterator   end(void) const;
	
private:
	ChildrenIter_t getChildModule( const char *pModname );
	
	void add( const char *name, NodeType type );
	
	//********************************************
	//    �����q�̂��߂Ɍ��J (�댯)
	//********************************************
private:
	ChildrenIter_t beginChildren( void ) const { return mpChildren->begin(); }
	ChildrenIter_t   endChildren( void ) const { return mpChildren->end(); }
	
};

//##############################################################################
//                �錾�� : CVarTree::iterator
//##############################################################################
class CVarTree::iterator
	: public std::iterator<std::forward_iterator_tag, CVarTree, void>
{
	friend class CVarTree;
	
private:
	typedef CVarTree Elem_t;
	typedef CVarTree::ChildrenIter_t iter_t;
	typedef CVarTree::iterator       self_t;
	
	//********************************************
	//    �����o�ϐ�
	//********************************************
private:
	CVarTree *mpOwner;
	iter_t  mIter;		// ����
	
	Elem_t* mpData;
	
public:
	//--------------------------------------------
	// �\�z (�ʏ�)
	// 
	// @ �擪(begin)�ɐݒ肳���
	//--------------------------------------------
	iterator( CVarTree* pOwner )
		: mpOwner   ( pOwner )
		, mpData    ( NULL )
	{
		moveToBegin();
		return;
	}
	
	//--------------------------------------------
	// �\�z (����)
	//--------------------------------------------
	iterator( const self_t& src )
		: mpOwner   ( src.mpOwner )
		, mIter     ( src.mIter   )
		, mpData    ( src.mpData  )
	{ }
	
	/*
	//-----------------------------------------------
	// �\�z (�I�[�ʒu)
	//-----------------------------------------------
	iterator( CVarTree* pOwner, int n )
		: 
	{ }
	//*/
	
	//--------------------------------------------
	// �E�Q��
	//--------------------------------------------
	Elem_t& operator *() const
	{
		return *mpData;
	}
	
	Elem_t* operator ->()
	{
		return mpData;
	}
	
	//--------------------------------------------
	// �ړ�����
	//--------------------------------------------
	// �O�u
	self_t& operator ++(void)
	{
		moveToNext();
		return *this;
	}
	
	// ��u
	self_t operator ++(int)
	{
		self_t obj_bak( *this );		// ���݂̈ʒu��ۑ����Ă���
		++ (*this);
		return obj_bak;
	}
	
	self_t operator +(int n)
	{
		self_t iter( *this );
		return ++ iter;
	}
	
	//--------------------------------------------
	// ��r���Z�q
	//--------------------------------------------
	const bool operator ==(const self_t& iter) const
	{
		return ( mpData == iter.mpData );
	}
	
	const bool operator !=(const self_t& iter) const
	{
		return !(*this == iter);
	}
	
private:
	//--------------------------------------------
	// ���Ɉړ�����
	//--------------------------------------------
	void moveToNext( void )
	{
		// �I�[�ɗ��Ă�����
		if ( mIter == mpOwner->endChildren() ) {
			mpData = NULL;
			return;
		}
		
		// ���Ɉړ�����
		mpData = &(mIter->second);
		
		++ mIter;
		
		return;
	}
	
	//------------------------------------------------
	// �擪(begin)�Ɉړ�����
	//------------------------------------------------
	void moveToBegin( void )
	{
		if ( mpOwner->getType() == CVarTree::NodeType_Module ) {
			mIter  = mpOwner->beginChildren();
			mpData = NULL;
			
			moveToNext();	// ��������
			
		} else {
			mpData = NULL;
		}
		return;
	}
	
	//------------------------------------------------
	// �I�[(end)�Ɉړ�����
	//------------------------------------------------
	void moveToEnd( void )
	{
		mpData = NULL;
		return;
	}
	
	//############################################
	//    ����
	//############################################
private:
	iterator();
	
};

#endif
