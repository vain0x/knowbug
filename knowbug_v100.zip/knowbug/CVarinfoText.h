// �ϐ��f�[�^�e�L�X�g�����N���X

#ifndef IG_CLASS_VARINFO_TEXT_H
#define IG_CLASS_VARINFO_TEXT_H

#include "ClhspDebugInfo.h"
#include "mod_cstring.h"

//##############################################################################
//                �錾�� : CVarinfoText
//##############################################################################
class CVarinfoText
{
	//******************************************************
	//    �����o�ϐ�
	//******************************************************
private:
	DebugInfo&  mdbginfo;
	CString    *mpBuf;
	PVal       *mpVar;
	const char *mpName;
	
	//******************************************************
	//    �����o�֐�
	//******************************************************
public:
	explicit CVarinfoText( DebugInfo& dbginfo, PVal *pval, const char *varname );
	~CVarinfoText();
	
	const CString& getString(void) const
	{
		return *mpBuf;
	}
	
	void make( void );
	
private:
	// �e�L�X�g�̐���
	void dumpVar( PVal *pval );
	void dump( void *mem, size_t size );
	
	// ���ڂ̒ǉ�
	void addItem( const char *name, const char *string );
	void addItem( const char *name, const char *format, ... );
	
	// ������̘A��
	void cat ( const char *string );
	void catf( const char *format, ... );
	void cat_crlf( void );
	
	// ���̑�
	static const char *getModeString( varmode_t mode )
	{
		return	( mode <= HSPVAR_MODE_NONE   ) ? "����" :
				( mode == HSPVAR_MODE_MALLOC ) ? "����" :
				( mode == HSPVAR_MODE_CLONE  ) ? "�N���[��" : "???"
		;
	}
	
	//******************************************************
	//    ����
	//******************************************************
private:
	CVarinfoText();
	
};

#endif
