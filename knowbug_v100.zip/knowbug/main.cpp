
//
//		HSP debug window support functions for HSP3
//				onion software/onitama 2005
//

#pragma comment(lib, "comctl32.lib")

#include <stdio.h>
#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>

#include "supio.h"
#include "resource.h"
#include "hspdll.h"
#include "main.h"
#include "sortnote.h"

static HSP3DEBUG *g_debug;
static HWND hDlgWnd;
static HINSTANCE myinst;

#define IDU_TAB 100
#define ID_BTN1 1000
#define ID_BTN2 1001
#define ID_BTN3 1002

#define TABDLGMAX 3
#define myClass "KNOWBUG"

#define DIALOG_X0 5
#define DIALOG_Y0 5
#define DIALOG_X1 366
#define DIALOG_Y1 406
#define DIALOG_Y2 23

#define WND_SX 380
#define WND_SY 480

static HWND g_hTabCtrl;
static HWND g_hGenList;
static HWND g_hTabSheet[TABDLGMAX];

static HWND g_hVarPage;
static HWND g_hVarTree;
static HWND g_hVarEdit;

static HWND g_hBtn1;
static HWND g_hBtn2;
static HWND g_hBtn3;
static HWND g_hSttCtrl;

static HWND g_hLogPage;
static HWND g_hLogEdit;
static HWND g_hLogChkUpdate;

typedef BOOL (CALLBACK *HSP3DBGFUNC)(HSP3DEBUG *,int,int,int);

//----------------------------------------------------------

static HSPCTX*       ctx( NULL );
static HSPEXINFO* exinfo( NULL );

//----------------------------------------------------------

#include <stack>
#include "mod_cstring.h"
#include "../../../hsp3/mod_cast.h"
#include "ClhspDebugInfo.h"
#include "CVarTree.h"
//#include "CVarinfoTree.h"
#include "CVarinfoText.h"
#define dbgmsg(msg) MessageBox( NULL, msg, "Debug Window", MB_OK )

static DebugInfo  g_dbginfo_inst;
static DebugInfo *g_dbginfo      ( &g_dbginfo_inst );
static CVarTree *stt_pSttVarTree ( NULL );
static CString  *stt_pLogmsg     ( NULL );

static CVarTree *getSttVarTree( void );
static void VarTree_addNode( CVarTree& tree, HWND hwndTree, HTREEITEM hParent );

//----------------------------------------------------------

//------------------------------------------------
// Dll�G���g���[�|�C���g
//------------------------------------------------
int WINAPI DllMain(HINSTANCE hInstance, DWORD fdwReason, PVOID pvReserved)
{
	switch ( fdwReason ) {
		case DLL_PROCESS_ATTACH:
			myinst = hInstance;
			hDlgWnd = NULL;
			break;
		
		case DLL_PROCESS_DETACH:
#ifndef clhsp
			if ( stt_pSttVarTree ) {
				delete stt_pSttVarTree; stt_pSttVarTree = NULL;
			}
			if ( stt_pLogmsg ) {
				delete stt_pLogmsg; stt_pLogmsg = NULL;
			}
#endif
			if ( hDlgWnd != NULL ) {
				DestroyWindow( hDlgWnd );
				hDlgWnd = NULL;
			}
			break;
	}
	return TRUE;
}

//------------------------------------------------
// �E�B���h�E�E�I�u�W�F�N�g�̐���
//------------------------------------------------
static HWND GenerateObj( HWND parent, char *name, char *ttl, int x, int y, int sx, int sy, int menu, HFONT font )
{
	HWND h = CreateWindow(
		name, ttl,
		WS_CHILD | WS_VISIBLE,
		x, y, sx, sy,
		parent,
		(HMENU)menu,
		myinst,
		NULL
	);

	if ( font != NULL ) SendMessage( h, WM_SETFONT, (WPARAM)font, TRUE );
	return h;
}

//------------------------------------------------
// �S�ʃ^�u�̑O����
//------------------------------------------------
static void TabGeneralInit( void )
{
	LVCOLUMN col;
	col.mask     = LVCF_FMT | LVCF_TEXT | LVCF_WIDTH | LVCF_SUBITEM;
	col.fmt      = LVCFMT_LEFT;
	col.cx       = 120;
	col.pszText  = "����";
	col.iSubItem = 0;
	ListView_InsertColumn( g_hGenList , 0 , &col);
	
	col.cx       = 400;
	col.iSubItem = 1;
	col.pszText  = "���e";
	ListView_InsertColumn( g_hGenList , 1 , &col);
	return;
}

//------------------------------------------------
// �S�ʃ^�u�̍X�V
//------------------------------------------------
static void TabGeneralReset( void )
{
	LV_ITEM item;
	int chk, tgmax;
	char *p;
	char name[256];
	char val[512];

	ListView_DeleteAllItems( g_hGenList );
	tgmax = 0;

	p = g_debug->get_value( DEBUGINFO_GENERAL );		// HSP���ɖ₢���킹
	strsp_ini();
	for (;;) {
		chk = strsp_get( p, name, 0, 255 );
		if ( chk == 0 ) break;
		
		chk = strsp_get( p, val, 0, 511 );
		if ( chk == 0 ) break;

		item.mask     = LVIF_TEXT;
		item.iItem    = tgmax;
		item.iSubItem = 0;
		item.pszText  = name;
		
		ListView_InsertItem( g_hGenList, &item );
		item.iSubItem = 1;
		item.pszText  = val;
		ListView_SetItem( g_hGenList, &item );

		tgmax ++;
	}
	g_debug->dbg_close( p );
	return;
}

//------------------------------------------------
// ���s���̈ʒu���X�V���� (line, file)
//------------------------------------------------
static void CurrnetUpdate( void )
{
	char tmp[512];
	char *fn;
	g_debug->dbg_curinf();
	fn = g_debug->fname;
	if ( fn == NULL ) fn = "???";
	sprintf_s( tmp, "%s\n( line : %d )", fn, g_debug->line );
	SetWindowText( g_hSttCtrl, tmp );
	return;
}

//------------------------------------------------
// �ϐ��^�u�̃I�v�V�������擾
//------------------------------------------------
static int GetTabVarsOption( void )
{
	return 0xF;
/*
	int opt( 0 );
	if ( IsDlgButtonChecked( g_hVarPage, IDC_MODULE ) ) opt |= 2;
	if ( IsDlgButtonChecked( g_hVarPage, IDC_ARRAY  ) ) opt |= 4;
	if ( IsDlgButtonChecked( g_hVarPage, IDC_DUMP   ) ) opt |= 8;
	return opt;
//*/
}

//------------------------------------------------
// �ϐ��^�u�̍X�V
//------------------------------------------------
static void TabVarsReset( void )
{
	TreeView_DeleteAllItems( g_hVarTree );
	
	// �ÓI�ϐ����X�g���c���[�ɒǉ�����
	CVarTree* pVarTree = getSttVarTree();
	
	VarTree_addNode( *pVarTree, g_hVarTree, TVI_ROOT );
	
	TreeView_Expand( g_hVarTree, TreeView_GetRoot(g_hVarTree), TVE_EXPAND );
	
	return;
}

//------------------------------------------------
// �ϐ��^�u::�ϐ����̍X�V
//------------------------------------------------
static void TabVarsUpdate( void )
{
	HTREEITEM hItem = TreeView_GetSelection(g_hVarTree);
	
	char name[256];
	
	TVITEM ti;
	ti.hItem      = hItem;
	ti.mask       = TVIF_TEXT;
	ti.pszText    = &name[0];
	ti.cchTextMax = 255;
	
	if ( TreeView_GetItem(g_hVarTree, &ti) ) {
		
		// ���W���[���̏��
		if ( name[0] == '@' ) {
			return;
			
		// �ϐ��̏��
		} else {
		/*
			char *p = g_debug->get_varinf( name, GetTabVarsOption() );	// HSP���ɖ₢���킹
			
			SetWindowText( g_hVarEdit, p );
			
			g_debug->dbg_close( p );
		/*/
			int idVar = exinfo->HspFunc_seekvar( name );
			if ( idVar < 0 ) {
				dbgmsg( strf("\"%s\"�͐ÓI�ϐ��̖��̂ł͂Ȃ��B", name).c_str() );
				return;
			}
			PVal *pval = &ctx->mem_var[idVar];
			
			CVarinfoText *varinf ( new CVarinfoText( *g_dbginfo, pval, name ) );
			
			varinf->make();
			
			SetWindowText( g_hVarEdit, varinf->getString().c_str() );
			
			delete varinf;
		//*/
		}
	}

	return;
}

//------------------------------------------------
// ���O���b�Z�[�W��ǉ��E�X�V����
//------------------------------------------------
static void TabLogAdditionalUpdate( const char *text )
{
	int caret[2];
	SendMessage( g_hLogEdit, EM_GETSEL,
		almighty_cast<WPARAM>( &caret[0] ),
		almighty_cast<LPARAM>( &caret[1] )
	);
	
	int size = Edit_GetTextLength( g_hLogEdit );
	Edit_SetSel( g_hLogEdit, size, size );		// �Ō���ɃL�����b�g��������
	Edit_ReplaceSel( g_hLogEdit, text );		// ������(str)��ǉ�����
	Edit_ScrollCaret( g_hLogEdit );				// ��ʂ�K�v�Ȃ����X�N���[��
	
	// �I����Ԃ����ɖ߂�
	Edit_SetSel( g_hLogEdit, caret[0], caret[1] );
	return;
}

//------------------------------------------------
// ���O���b�Z�[�W���X�V���� (commit)
//------------------------------------------------
static void TabLogCommit( void )
{
	if ( stt_pLogmsg == NULL || stt_pLogmsg->empty() ) return;
	
	TabLogAdditionalUpdate( stt_pLogmsg->c_str() );
	stt_pLogmsg->clear();
	return;
}

//------------------------------------------------
// ���O���b�Z�[�W�ɒǉ�����
//------------------------------------------------
static void TabLogAdd( char *str )
{
	// �����X�V
	if ( IsDlgButtonChecked( g_hLogPage, IDC_CHK_UPDATE ) ) {
		
		TabLogAdditionalUpdate( str );
		
	} else {
		if ( stt_pLogmsg == NULL ) {
			stt_pLogmsg = new CString;
			stt_pLogmsg->reserve( 0x400 + 1 );
		}
		
		stt_pLogmsg->append( str );
	}
	
	return;
}

//------------------------------------------------
// �S�ʃ^�u::�v���V�[�W��
//------------------------------------------------
LRESULT CALLBACK TabGeneralProc(HWND hDlg, UINT msg, WPARAM wp, LPARAM lp)
{
	switch ( msg ) {
		
		case WM_INITDIALOG:
			g_hGenList = GetDlgItem( hDlg, IDC_LV_GENERAL );
			TabGeneralInit();
			TabGeneralReset();
			return TRUE;
			
		case WM_COMMAND:
			switch ( LOWORD(wp) ) {
				case IDC_BTN_UPDATE:
					TabGeneralReset();
					break;
			}
			return FALSE;
	}
	
	return FALSE;
}

//------------------------------------------------
// �ϐ��^�u::�v���V�[�W��
//------------------------------------------------
LRESULT CALLBACK TabVarsProc(HWND hDlg, UINT msg, WPARAM wp, LPARAM lp)
{
	switch ( msg ) {
		case WM_INITDIALOG:
			g_hVarPage = hDlg;
			g_hVarTree = GetDlgItem( hDlg, IDC_VARTREE );
			g_hVarEdit = GetDlgItem( hDlg, IDC_VARINFO );
			
			TabVarsReset();
			return TRUE;
			
		/*
		case WM_COMMAND:
			switch ( LOWORD(wp) ) {
			}
			return FALSE;
		//*/
			
		case WM_NOTIFY:
		{
			NMHDR* nmhdr = (LPNMHDR)lp;
			
			if ( nmhdr->idFrom == IDC_VARTREE ) {
				switch ( nmhdr->code ) {
					
					// �I�����ڂ��ω�����
					case TVN_SELCHANGED:
					case NM_DBLCLK:
					case NM_RETURN:
						TabVarsUpdate();
						break;
				}
			}
			break;
		}
	}
	return FALSE;
}

//------------------------------------------------
// ���O�^�u::�v���V�[�W��
//------------------------------------------------
LRESULT CALLBACK TabLogProc(HWND hDlg, UINT msg, WPARAM wp, LPARAM lp)
{
	switch ( msg ) {
		case WM_INITDIALOG:
			g_hLogPage = hDlg;
			g_hLogEdit = GetDlgItem( hDlg, IDC_LOG );
			g_hLogChkUpdate = GetDlgItem( hDlg, IDC_CHK_UPDATE );
			
			CheckDlgButton( g_hLogPage, IDC_CHK_UPDATE, BST_CHECKED );
			return TRUE;
			
		case WM_COMMAND:
			switch ( LOWORD(wp) ) {
				
				case IDC_CHK_UPDATE:
					// �`�F�b�N���t����ꂽ�Ƃ�
					if ( IsDlgButtonChecked( g_hLogPage, IDC_CHK_UPDATE ) ) {
						TabLogCommit();
					}
					break;
					
			//	case IDC_BTN_CLEAR:
			//		TabLogClear();
			//		break;
			}
			return FALSE;
	}
	return FALSE;
}

//------------------------------------------------
// �e�_�C�A���O�̃R�[���o�b�N�֐�
//------------------------------------------------
LRESULT CALLBACK DlgProc(HWND hDlg, UINT msg, WPARAM wp, LPARAM lp)
{
	TCITEM	tc;
	RECT	rt;
	LPPOINT pt = (LPPOINT) &rt;
	HFONT hf;

	switch ( msg ) {

	// ������
	case WM_CREATE:
		
		hf = (HFONT)GetStockObject( DEFAULT_GUI_FONT );
		g_hTabCtrl = GenerateObj( hDlg, WC_TABCONTROL, "", DIALOG_X0, DIALOG_Y0, DIALOG_X1, DIALOG_Y2, IDU_TAB, hf );
		g_hSttCtrl = GenerateObj( hDlg, "static",    "",  DIALOG_X0 + 180, DIALOG_Y1 + 4, DIALOG_X1 - 180, 48, 0, hf );
		g_hBtn1    = GenerateObj( hDlg, "button", "���s", DIALOG_X0 +   8, DIALOG_Y1 + 4, 80, 24, ID_BTN1, hf );
		g_hBtn2    = GenerateObj( hDlg, "button", "���s", DIALOG_X0 +  88, DIALOG_Y1 + 4, 40, 24, ID_BTN2, hf );
		g_hBtn3    = GenerateObj( hDlg, "button", "��~", DIALOG_X0 + 128, DIALOG_Y1 + 4, 40, 24, ID_BTN3, hf );
		
		// �S�ʃ^�u��ǉ�
		tc.mask = TCIF_TEXT;
		tc.pszText = "�S��";
		TabCtrl_InsertItem(g_hTabCtrl, 0, &tc);
		g_hTabSheet[0] = CreateDialog( myinst, "T_GENERAL", hDlg, (DLGPROC) TabGeneralProc );
		
		// �ϐ��^�u��ǉ�
		tc.mask = TCIF_TEXT;
		tc.pszText = "�ϐ�";
		TabCtrl_InsertItem(g_hTabCtrl, 1, &tc);
		g_hTabSheet[1] = CreateDialog( myinst, "T_VAR", hDlg, (DLGPROC) TabVarsProc );

		// ���O�^�u��ǉ�
		tc.mask    = TCIF_TEXT;
		tc.pszText = "���O";
		TabCtrl_InsertItem(g_hTabCtrl, 2, &tc);
		g_hTabSheet[2] = CreateDialog( myinst, "T_LOG", hDlg, (DLGPROC) TabLogProc );

		//GetClientRect(g_hTabCtrl, &rt);
		SetRect( &rt, 8, DIALOG_Y2 + 4, DIALOG_X1 + 8, DIALOG_Y1 + 4 );
		//TabCtrl_AdjustRect(g_hTabCtrl, FALSE, &rt);
		//MapWindowPoints(g_hTabCtrl, hDlg, pt, 2);

		// ���������q�_�C�A���O���^�u�V�[�g�̏�ɓ\��t����
		for ( int i = 0; i < TABDLGMAX; ++ i ) {
			MoveWindow(
				g_hTabSheet[i],
				rt.left,
				rt.top,
				rt.right  - rt.left,
				rt.bottom - rt.top,
				FALSE
			);
		}

		// �f�t�H���g�ō����̃^�u��\��
		ShowWindow( g_hTabSheet[0], SW_SHOW );
		return TRUE;

	case WM_NOTIFY:
	{
		NMHDR *nm = (NMHDR *)lp;		// �^�u�R���g���[���̃V�[�g�؂�ւ��ʒm
		int cur   = TabCtrl_GetCurSel(g_hTabCtrl);
		for ( int i = 0; i < TABDLGMAX; ++ i ) {
			if ( i == cur ) {
				ShowWindow( g_hTabSheet[i], SW_SHOW );
			} else {
				ShowWindow( g_hTabSheet[i], SW_HIDE );
			}
		}
		break;
	}
	case WM_COMMAND:
		switch ( LOWORD(wp) ) {
		case ID_BTN1:
			g_debug->dbg_set( HSPDEBUG_RUN );
			SetWindowText( g_hSttCtrl, "" );
			break;
		case ID_BTN2:
			g_debug->dbg_set( HSPDEBUG_STEPIN );
			SetWindowText( g_hSttCtrl, "" );
			break;
		case ID_BTN3:
			g_debug->dbg_set( HSPDEBUG_STOP );
			break;
		}
		break;
		
	case WM_CLOSE:
		return FALSE;
		
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	}
	return DefWindowProc(hDlg, msg, wp, lp) ;
}

//##############################################################################
//        �f�o�b�O�E�B���h�E::clhsp����Ă΂�����
//##############################################################################
//------------------------------------------------
// debugini ptr  (type1)
//------------------------------------------------
EXPORT BOOL WINAPI debugini( HSP3DEBUG *p1, int p2, int p3, int p4 )
{
	int dispx, dispy;
	WNDCLASS wndclass;

	g_debug = p1;
	ctx     = p1->hspctx;
	exinfo  = ctx->exinfo2;
	
	g_dbginfo->debug  = p1;
	g_dbginfo->ctx    = p1->hspctx;
	g_dbginfo->exinfo = g_dbginfo->ctx->exinfo2;
	
	dispx   = GetSystemMetrics( SM_CXSCREEN );
	dispy   = GetSystemMetrics( SM_CYSCREEN );

	wndclass.style         = CS_HREDRAW | CS_VREDRAW;
	wndclass.lpfnWndProc   = DlgProc;
	wndclass.cbClsExtra    = 0;
	wndclass.cbWndExtra    = 0;
	wndclass.hInstance     = myinst;
	wndclass.hIcon         = NULL;
	wndclass.hCursor       = LoadCursor(NULL,IDC_ARROW);
	wndclass.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);
	wndclass.lpszMenuName  = NULL;
	wndclass.lpszClassName = myClass;
	RegisterClass( &wndclass );

	hDlgWnd = CreateWindow(
		myClass,
		"Debug Window",
		WS_CAPTION | WS_OVERLAPPED | WS_BORDER | WS_VISIBLE,
		dispx - WND_SX, 0,
		WND_SX, WND_SY,
		NULL,
		NULL,
		myinst,
		NULL
	);
	ShowWindow( hDlgWnd, SW_SHOW );
	UpdateWindow( hDlgWnd );

	// hDlgWnd = CreateDialog( myinst, "HSP3DEBUG", NULL, (DLGPROC)DlgProc );
	if ( hDlgWnd == NULL ) {
		MessageBox( NULL, "Debug window initalizing failed.", "Error", 0 );
	}
	ShowWindow( hDlgWnd, SW_SHOW );
    UpdateWindow( hDlgWnd );
	
	return 0;
}

//------------------------------------------------
// debug_notice ptr  (type1)
// 
// @prm p2 : 0 = stop event,
// @       : 1 = send message (logmes)
//------------------------------------------------
EXPORT BOOL WINAPI debug_notice( HSP3DEBUG *p1, int p2, int p3, int p4 )
{
	switch ( p2 ) {
		// ���s����~���� (stop, wait, await, assert �Ȃ�)
		case DebugNotice_Stop:
		{
			CurrnetUpdate();
			int idxTab = TabCtrl_GetCurSel(g_hTabCtrl);
			switch( idxTab ) {
				case 0:
					TabGeneralReset();
					break;
				case 1:
					TabVarsUpdate();
					break;
			}
			break;
		}
		
		// logmes ���߂��Ă΂ꂽ
		case DebugNotice_Logmes:
			strcat_s( ctx->stmp, 1024, "\r\n" );
			TabLogAdd( ctx->stmp );
			break;
	}
	return 0;
}

#ifdef clhsp

//------------------------------------------------
// debugbye ptr  (type1)
//------------------------------------------------
EXPORT BOOL WINAPI debugbye( HSP3DEBUG *p1, int p2, int p3, int p4 )
{
	if ( stt_pSttVarTree ) {
		delete stt_pSttVarTree; stt_pSttVarTree = NULL;
	}
	if ( stt_pLogmsg ) {
		delete stt_pLogmsg; stt_pLogmsg = NULL;
	}
	return 0;
}

#endif

//##############################################################################
//               �������֐�
//##############################################################################
//------------------------------------------------
// �ÓI�ϐ����X�g���擾����
//------------------------------------------------
static CVarTree *getSttVarTree( void )
{
	CVarTree*& vartree = stt_pSttVarTree;
	
	// �ϐ����X�g�����
	if ( vartree == NULL ) {
		
		char name[256];
		
		// �ÓI�ϐ����X�g���擾����
		char *p = g_debug->get_varinf( NULL, 0xFF );	// HSP���ɖ₢���킹
		SortNote( p );
		
		vartree = new CVarTree( "", CVarTree::NodeType_Module );
		
		strsp_ini();
		for (;;) {
			int chk = strsp_get( p, name, 0, 255 );
			if ( chk == 0 ) break;
			
			vartree->push_var( name );
		}
		
		g_debug->dbg_close( p );
	}
	
	return vartree;
}

//------------------------------------------------
// �ϐ��c���[�ɗv�f��ǉ�����
//------------------------------------------------
static void VarTree_addNode( CVarTree& tree, HWND hwndTree, HTREEITEM hParent )
{
	TVINSERTSTRUCT tvis;
	tvis.hParent      = hParent;
	tvis.hInsertAfter = TVI_SORT;
	tvis.item.mask    = TVIF_TEXT;
	
	switch ( tree.getType() )
	{
		// �ϐ��m�[�h
		case CVarTree::NodeType_Var:
		{
			tvis.item.pszText = const_cast<char *>( tree.getName().c_str() );
			hParent = TreeView_InsertItem( hwndTree, &tvis );
			break;
		}
		
		// ���W���[���E�m�[�h
		case CVarTree::NodeType_Module:
		{
			CString modname( "@" );
			modname.append( tree.getName() );
			
			tvis.item.pszText = const_cast<char *>( modname.c_str() );
			hParent = TreeView_InsertItem( hwndTree, &tvis );
			
			// ���ꂼ��̎q�m�[�h�ɂ��čċA����
			for ( CVarTree::iterator iter = tree.begin()
				; iter != tree.end()
				; ++ iter
			) {
				VarTree_addNode( *iter, hwndTree, hParent );
			}
			
			break;
		}
	}
	
	return;
}

