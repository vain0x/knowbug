//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by knowbug.rc
//
#define IDC_TAB1                        1007
#define IDC_LV_GENERAL                  1008
#define IDC_EDIT1                       1009
#define IDC_BTN_UPDATE                  1010
#define IDC_SORT                        1011
#define IDC_MODULE                      1012
#define IDC_ARRAY                       1013
#define IDC_DUMP                        1014
#define IDC_VARINFO                     1016
#define IDC_LOG                         1017
#define IDC_MFCSHELLLIST1               1018
#define IDC_VARTREE                     1019
#define IDC_CHK_UPDATE                  1024
#define IDC_BTN_CLEAR                   1025

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1026
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
