
#ifndef __sortnote_h
#define __sortnote_h

void SortNote( char *str );

#endif

