// It is dummy for Visual C++ Express Edition
#include <windows.h>
