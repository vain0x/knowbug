// �ϐ��f�[�^�e�L�X�g�����N���X

#include "CVarinfoText.h"
#include "CVarinfoTree.h"
#include "../../../hsp3/mod_cast.h"

#ifdef clhsp
# include "../../../hsp3/mod_vector.h"
#endif

//##############################################################################
//                ��`�� : CVarinfoText
//##############################################################################
//------------------------------------------------
// �\�z
//------------------------------------------------
CVarinfoText::CVarinfoText( DebugInfo& dbginfo, PVal *pval, const char *varname )
	: mdbginfo ( dbginfo )
	, mpBuf    ( new CString )
	, mpVar    ( pval )
	, mpName   ( varname )
{
	mpBuf->reserve( 0x400 );
	return;
}

//------------------------------------------------
// ���
//------------------------------------------------
CVarinfoText::~CVarinfoText()
{
	delete mpBuf; mpBuf = NULL;
	return;
}

//------------------------------------------------
// ����
//------------------------------------------------
void CVarinfoText::make( void )
{
	PVal *& pval = mpVar;
	void *ptr;
	int size;

	HspVarProc *pHvp ( mdbginfo.exinfo->HspFunc_getproc( pval->flag ) );
	
	// �ϐ��Ɋւ�����
	catf( "�ϐ����F%s", mpName );
	catf( "�ϐ��^�F%s", pHvp->vartype_name );
	catf( "�z�� " BracketIdxL "%d, %d, %d" BracketIdxR,
		PValLength( pHvp, pval, 1 ),
		PValLength( pHvp, pval, 2 ),
		PValLength( pHvp, pval, 3 )
	);
	catf( "���[�h�F%s", getModeString( pval->mode ) );
	catf( "�A�h���X�F0x%08X", address_cast(pval->pt) );
	catf( "�}�X�^�[�F0x%08X", address_cast(pval->master) );
	catf( "�g�p�T�C�Y�F%d",   pval->size );
	
	HspVarCoreReset( pval );
	ptr = pHvp->GetPtr( pval );
	pHvp->GetBlockSize( pval, ptr_cast<PDAT *>(ptr), &size );
	catf( "�o�b�t�@�T�C�Y�F%d", size );
	
	cat_crlf();
	
	// �ϐ��̓��e�Ɋւ�����
	{
		CVarinfoTree *varinf ( new CVarinfoTree( mdbginfo ) );
		
		varinf->addVar( pval, mpName );
		
		cat( varinf->getString().c_str() );
		
		delete varinf;
	}
	
	// �������_���v
	dumpVar( pval );
	
	return;
}

//------------------------------------------------
// �ϐ����������_���v����
//------------------------------------------------
void CVarinfoText::dumpVar( PVal *pval )
{
	size_t size;
	
	HspVarCoreReset( pval );
	HspVarProc *pHvp ( mdbginfo.exinfo->HspFunc_getproc( pval->flag ) );
	void *ptr ( pHvp->GetPtr( pval ) );
	void *mem ( pHvp->GetBlockSize( pval, ptr_cast<PDAT *>(ptr), ptr_cast<int *>(&size) ) );
	
	dump( mem, size );
	
	return;
}

//------------------------------------------------
// �������_���v��ǉ�����
//------------------------------------------------
void CVarinfoText::dump( void *mem, size_t size )
{
	static const size_t stc_maxsize( 0x10000 );
	
	if ( size > stc_maxsize ) {
		catf( "�S%d�o�C�g�̓��A%d�o�C�g�݂̂��_���v���܂��B", size, stc_maxsize );
		size = stc_maxsize;
	}
	
	char tline[1024];
	size_t iWrote;
	uint idx ( 0 );
	
	cat("dump  0  1  2  3  4  5  6  7  8  9  A  B  C  D  E  F");
	cat("----------------------------------------------------");
	
	while ( idx < size ) {
		iWrote = sprintf_s( tline, "%04X", idx );
		
		for ( uint i = 0; (i < 0x10 && idx < size); ++ i, ++ idx ) {
			iWrote += sprintf_s(
				&tline[iWrote], 1024 - iWrote,
				" %02X", static_cast<unsigned char>( ptr_cast<char *>(mem)[idx] )
			);
		}
		
		cat( tline );
	}
	
	return;
}

//**********************************************************
//        �������֐�
//**********************************************************
//------------------------------------------------
// ���s��A������
//------------------------------------------------
void CVarinfoText::cat_crlf( void )
{
	mpBuf->append( "\r\n" );
	return;
}

//------------------------------------------------
// �������A������
//------------------------------------------------
void CVarinfoText::cat( const char *string )
{
	mpBuf->append( string );
	cat_crlf();
	return;
}

//------------------------------------------------
// �����t���������A������
//------------------------------------------------
void CVarinfoText::catf( const char *format, ... )
{
	va_list   arglist;
	va_start( arglist, format );
	
	cat( vstrf( format, arglist ).c_str() );
	
	va_end( arglist );
	return;
}
