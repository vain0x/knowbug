// �ϐ��f�[�^�̃c���[�`��������

#ifndef IG_CLASS_VARINFO_TREE_H
#define IG_CLASS_VARINFO_TREE_H

#include "ClhspDebugInfo.h"
#include "mod_cstring.h"

//##############################################################################
//                �錾�� : CVarinfoTree
//##############################################################################
class CVarinfoTree
{
private:
	static const int stc_cntUnitIndent = 3;		// �������P�ʗ�
	static const char *stc_fmt_elemname[5];		// �z��v�f���̏���
	
	struct BaseData
	{
		CString sIndent;
		const char *name;
		const char *indent;
		
		BaseData( const char *name_, const CString& sIndent_ )
			: name    ( name_ )
			, sIndent ( sIndent_ )
			, indent  ( sIndent.c_str() )
		{ }
		
		const char *getName  ( void ) const { return name; }
		const char *getIndent( void ) const { return sIndent.c_str(); }
		
	};
	
	//******************************************************
	//    �����o�ϐ�
	//******************************************************
private:
	DebugInfo& mdbginfo;
	CString   *mpBuf;
	int mlvNest;
	
	//******************************************************
	//    �����o�֐�
	//******************************************************
public:
	explicit CVarinfoTree( DebugInfo& dbginfo );
	~CVarinfoTree();
	
	void addVar( PVal *pval, const char *name );
	
	const CString& getString(void) const
	{
		return *mpBuf;
	}
	
private:
	// ���ڂ̒ǉ�
	void addItem_value    ( const BaseData& base, vartype_t type, void *ptr );
	void addItem_var      ( const BaseData& base, PVal *pval );
	void addItem_varScalar( const BaseData& base, PVal *pval );
	void addItem_varArray ( const BaseData& base, PVal *pval );
	void addItem_varStr   ( const BaseData& base, PVal *pval, bool bScalar );
	void addItem_vector   ( const BaseData& base, Vector *vec, int length );
	void addItem_modinst  ( const BaseData& base, ModInst *mv );
	void addItem_flexValue( const BaseData& base, FlexValue *fv );
	void addItem_prmstack ( const BaseData& base, STRUCTDAT *pStDat, STRUCTPRM *pStPrm, const void *prmstack );
	void addItem_member   ( const BaseData& base, STRUCTDAT *pStDat, STRUCTPRM *pStPrm, const void *member );
//	void addItem_string   ( const BaseData& base, const char *src );
	
	// ������̘A��
	void catf( const char *format, ... );
	void cat_crlf( void );
	
	// ���̑�
	CString getIndent(void) const
	{
		return CString( mlvNest * stc_cntUnitIndent, ' ' );
	}
	
	// �f�o�b�O������̐���
#ifndef clhsp
	CString getDbgString( vartype_t type, const void *ptr );
	CString toStringLiteralFormat( const char *src );
#endif
	
	//******************************************************
	//    ����
	//******************************************************
private:
	CVarinfoTree();
	
};

#endif
