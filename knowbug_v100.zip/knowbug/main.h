
//
//		Structure for HSP3 Debug Support
//
#ifndef IG_HSP3DBGWIN_H
#define IG_HSP3DBGWIN_H

#include "../../../hsp3/hsp3debug.h"
#include "../../../hsp3/hsp3struct.h"			// hsp3 core define

#include "../../../hsp3/mod_vector.h"

#endif

