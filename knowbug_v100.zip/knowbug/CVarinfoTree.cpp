// �ϐ��f�[�^�̃c���[�`��������

#include "CVarinfoTree.h"
#include "../../../hsp3/mod_cast.h"

#ifdef clhsp
# include "../../../hsp3/mod_vector.h"
#endif

static const char *getMPTypeString( int mptype );

//##############################################################################
//                ��`�� : CVarinfoTree
//##############################################################################
//------------------------------------------------
// �\�z
//------------------------------------------------
CVarinfoTree::CVarinfoTree( DebugInfo& dbginfo )
	: mdbginfo ( dbginfo )
	, mpBuf    ( new CString )
	, mlvNest  ( 0 )
{
	mpBuf->reserve( 0x400 );
	return;
}

//------------------------------------------------
// ���
//------------------------------------------------
CVarinfoTree::~CVarinfoTree()
{
	delete mpBuf; mpBuf = NULL;
	mlvNest = 0;
	return;
}

//------------------------------------------------
// [add] �ϐ�
//------------------------------------------------
void CVarinfoTree::addVar( PVal *pval, const char *name )
{
	BaseData base ( name, getIndent() );
	
	addItem_var( base, pval );
	return;
}

#if 0
//------------------------------------------------
// [add] �P�̕ϐ�
//------------------------------------------------
void CVarinfoTree::addVarScalar( PVal *pval, const char *name )
{
	BaseData base ( name, getIndent() );
	
	addItem_varScalar( base, pval );
	return;
}
#endif

//------------------------------------------------
// [add][item] �l
//------------------------------------------------
void CVarinfoTree::addItem_value( const BaseData& base, vartype_t type, void *ptr )
{
	if ( type == HSPVAR_FLAG_STRUCT ) {
#ifdef clhsp
		addItem_modinst( base, *ptr_cast<ModInst **>(ptr) );
#else
		addItem_flexValue( base, ptr_cast<FlexValue *>(ptr) );
#endif
//	} else if ( type == HSPVAR_FLAG_STR ) {
//		addItem_string( base, ptr_cast<char *>(ptr) );
		
	} else {
#ifdef clhsp
		char *p = mdbginfo.debug->dbg_toString( type, ptr );
		
		catf( "%s%s = %s", base.getIndent(), base.getName(), p );
		
		mdbginfo.debug->dbg_close( p );
#else
		catf( "%s%s = %s", base.getIndent(), base.getName(), getDbgString( type, ptr ).c_str() );
#endif
	}
	return;
}

//------------------------------------------------
// [add][item] �ϐ�
//------------------------------------------------
void CVarinfoTree::addItem_var( const BaseData& base, PVal *pval )
{
	HspVarProc *pHvp = mdbginfo.exinfo->HspFunc_getproc( pval->flag );
	int       length = PValLength( pHvp, pval, 1 );
	
	// ��
	if ( length == 0 ) {
		catf( "%s%s (empty)", base.getIndent(), base.getName() );
		
	// �P��
	} else if ( ( length == 1 && PValLength(pHvp, pval, 2) == 0 )
		&& pval->flag != HSPVAR_FLAG_VECTOR
	) {
		pval->offset = 0;
		addItem_varScalar( base, pval );
		
	// �z��
	} else {
		catf( "%s%s:", base.getIndent(), base.getName() );
		
		mlvNest ++;
		
#ifdef clhsp
		if ( pval->flag == HSPVAR_FLAG_VECTOR ) {
			addItem_vector( base, ptr_cast<Vector *>( pval->pt ), length );
		} else
#else
		{
			addItem_varArray( base, pval );
		}
#endif
		
		mlvNest --;
	}
	
	return;
}

//------------------------------------------------
// [add][item] �P�̕ϐ�
//------------------------------------------------
void CVarinfoTree::addItem_varScalar( const CVarinfoTree::BaseData& base, PVal *pval )
{
	HspVarProc *pHvp ( mdbginfo.exinfo->HspFunc_getproc( pval->flag ) );
	
	addItem_value( base, pval->flag, pHvp->GetPtr(pval) );
	return;
}

//------------------------------------------------
// [add][item] �z��ϐ� (array)
// 
// @ vector �^�͗��Ȃ��B
// @prm base : �e�v�f(�z��ϐ�)�̂���[��
//------------------------------------------------
void CVarinfoTree::addItem_varArray( const CVarinfoTree::BaseData& base, PVal *pval )
{
	BaseData baseChild ( NULL, getIndent() );
	
	HspVarProc *pHvp ( mdbginfo.exinfo->HspFunc_getproc(pval->flag) );
	
	size_t length[3] = { 0 };
	uint cntElem( 0 );
	uint maxdim ( 0 );
	
	// �S�v�f���ƍő原���𒲂ׂ�
	for ( int i = 0; i < ArrayDimMax; ++ i ) {
		length[i] = PValLength( pHvp, pval, i + 1 );
		
		if ( length[i] > 0 ) {
			if ( i == 0 ) cntElem = 1;
			cntElem *= length[i];
			maxdim  ++;
		} else break;
	}
	
	// �z����
	catf( "%s.vartype = %s", baseChild.getIndent(), pHvp->vartype_name );
	
	if ( maxdim <= 1 ) {
		catf( "%s.length  = %d", baseChild.getIndent(), length[0] );
	} else {
		catf( "%s.format  = %s (%d in total)",
			baseChild.getIndent(),
			strf( stc_fmt_elemname[maxdim], length[0], length[1], length[2] ).c_str(),
			cntElem
		);
	}

	// �e�v�f��ǉ�����
	for ( uint i = 0; i < cntElem; ++ i ) {
		
		// aptr �𕪉����ēY�������߂�
		APTR aptr ( i );
		APTR idx[ArrayDimMax] = { 0, 0, 0 };
		for ( uint idxDim = 0; idxDim < maxdim; ++ idxDim ) {
			idx[idxDim] = aptr % length[idxDim];
			aptr        = aptr / length[idxDim];
		}
		
		CString sName( strf(stc_fmt_elemname[maxdim], idx[0], idx[1], idx[2]) );
		baseChild.name = sName.c_str();
		
		// �v�f�̒l��ǉ� ( �֋X��A�P�̕ϐ��Ƃ��Ēǉ����� )
		pval->offset = i;
		addItem_varScalar( baseChild, pval );
	}
	
	return;
}

//------------------------------------------------
// [add][item] �ϐ� (vartype: str)
//------------------------------------------------
void CVarinfoTree::addItem_varStr( const BaseData& base, PVal *pval, bool bScalar )
{
	if ( bScalar ) {
		catf( "%s", ptr_cast<char *>( pval->pt ) );
		
	} else {
		addItem_varArray( base, pval );
	}
	return;
}

#ifdef clhsp
//------------------------------------------------
// [add][item] vector
//------------------------------------------------
void CVarinfoTree::addItem_vector( const BaseData& base, Vector *vec, int length )
{
	CString sName; sName.reserve( 5 );
	BaseData baseChild( NULL, getIndent() );
	
	for ( int i = 0; i < length; ++ i ) {
		
		PVal *pvElem = vec->list->at( i ).pval;
		
		sName = strf( "[%d]", i );
		baseChild.name = sName.c_str();
		
		// �ċA����
		addItem_var( baseChild, pvElem );
	}
	return;
}

//------------------------------------------------
// [add][item] modinst
//------------------------------------------------
void CVarinfoTree::addItem_modinst( const BaseData& base, ModInst *mv )
{
	if ( mv == NULL ) {
		catf( "%s%s = (nullmod)", base.getIndent(), base.getName() );
		return;
	}
	
	catf( "%s%s:", base.getIndent(), base.getName() );
	
	STRUCTPRM *pStPrm ( &mdbginfo.ctx->mem_minfo[mv->id_minfo] );
	STRUCTDAT *pStDat ( &mdbginfo.ctx->mem_finfo[pStPrm->subid] );
	void      *prmstack ( mv->members );
	
	addItem_prmstack( base, pStDat, pStPrm, prmstack );
	
	return;
}

#else

//------------------------------------------------
// [add][item] flex-value
//------------------------------------------------
void CVarinfoTree::addItem_flexValue( const BaseData& base, FlexValue *fv )
{
	if ( fv == NULL ) {
		catf( "%s[error] (addItem_flexValue) fv = NULL", base.getIndent() );
		return;
	}
	
	if ( fv->ptr == NULL || fv->type == FLEXVAL_TYPE_NONE ) {
		catf( "%s%s = (empty struct)", base.getIndent(), base.getName() );
		return;
	}
	
	catf( "%s%s:", base.getIndent(), base.getName() );
	
	if ( fv->type == FLEXVAL_TYPE_CLONE ) {
		mlvNest ++;
		catf( "%s@clone", getIndent().c_str() );
		mlvNest --;
	}
	
	STRUCTPRM *pStPrm ( &mdbginfo.ctx->mem_minfo[fv->customid] );
	STRUCTDAT *pStDat ( &mdbginfo.ctx->mem_finfo[pStPrm->subid] );
	
	addItem_prmstack( base, pStDat, pStPrm, fv->ptr );
	return;
}
#endif

//------------------------------------------------
// [add][item] prmstack
//------------------------------------------------
void CVarinfoTree::addItem_prmstack(
	const CVarinfoTree::BaseData& base,
	STRUCTDAT *pStDat,
	STRUCTPRM *pStPrm,
	const void *prmstack
)
{
	mlvNest ++;
	
	CString sName; sName.reserve( 5 );
	BaseData baseChild( NULL, getIndent() );
	
/*
	catf( "%s.id_finfo = %d", baseChild.getIndent(), pStDat->subid );
	catf( "%s.id_minfo = %d", baseChild.getIndent(), pStDat->prmindex );
//*/
	
	STRUCTPRM *pStPrmEnd( pStPrm + pStDat->prmmax );
	
	int i ( 0 );
	while ( pStPrm < pStPrmEnd )
	 {
		const void *member ( ptr_cast<const char *>(prmstack) + pStPrm->offset );
		
		sName = strf( BracketIdxL "%d" BracketIdxR, i );	// ���̖���
		baseChild.name = sName.c_str();
		
		addItem_member( baseChild, pStDat, pStPrm, member );
		
		// structtag => �����o�ł͂Ȃ��̂ŁA�����Ȃ�
		if ( pStPrm->mptype != MPTYPE_STRUCTTAG ) {
			i ++;
		}
		++ pStPrm;
	}
	
	mlvNest --;
	return;
}

//------------------------------------------------
// [add][item] �����o (in prmstack)
//------------------------------------------------
void CVarinfoTree::addItem_member(
	const CVarinfoTree::BaseData& base,
	STRUCTDAT *pStDat,
	STRUCTPRM *pStPrm,
	const void *member_const
)
{
	void *member ( const_cast<void *>(member_const) );
	
	switch ( pStPrm->mptype )
	{
		case MPTYPE_STRUCTTAG:
			catf( "%s.modcls = %s", base.getIndent(),
				&mdbginfo.ctx->mem_mds[pStDat->nameidx]
			);
			break;
			
		// �ϐ� (PVal *)
	//	case MPTYPE_VAR:
		case MPTYPE_SINGLEVAR:
		case MPTYPE_ARRAYVAR:
		{
			MPVarData *pVarDat ( ptr_cast<MPVarData *>(member) );
			
			pVarDat->pval->offset = pVarDat->aptr;
			
			addItem_var( base, pVarDat->pval );
			break;
		}
		// �ϐ� (PVal)
		case MPTYPE_VECTOR:
		case MPTYPE_LOCALVAR:
		case MPTYPE_ANY:
		case MPTYPE_FLEX:
		{
			PVal *pval ( ptr_cast<PVal *>(member) );
			addItem_var( base, pval );
			break;
		}
		// this�ϐ� (MPModInst)
		case MPTYPE_MODULEVAR:
		case MPTYPE_IMODULEVAR:
		case MPTYPE_TMODULEVAR:
		{
#ifdef clhsp
			MPModInst *modinst ( ptr_cast<MPModInst *>(member) );
			addItem_modinst( base, modinst->mv );
			break;
#else
			MPModVarData *modvar ( ptr_cast<MPModVarData *>(member) );
			PVal *pvSelf ( modvar->pval );
			pvSelf->offset = modvar->aptr;
			addItem_varScalar( base, pvSelf );
			break;
#endif
		}
		// ModInst (ModInst *) : clhsp�̂�
#ifdef clhsp
		case MPTYPE_STRUCT:
		{
			ModInst *mv2 ( *ptr_cast<ModInst **>(member) );
			addItem_modinst( base, mv2 );
			break;
		}
#endif
		// ������ (char **)
	//	case MPTYPE_STRING:
		case MPTYPE_LOCALSTRING:
		{
			char *pString ( *ptr_cast<char **>(member) );
			addItem_value( base, HSPVAR_FLAG_STR, pString );
			break;
		}
		// ���̑�
		case MPTYPE_DNUM:
		{
			addItem_value( base, HSPVAR_FLAG_DOUBLE, ptr_cast<double *>(member) );
			break;
		}
		case MPTYPE_INUM:
		{
			addItem_value( base, HSPVAR_FLAG_INT, ptr_cast<int *>(member) );
			break;
		}
		case MPTYPE_LABEL:
		{
			addItem_value( base, HSPVAR_FLAG_LABEL, ptr_cast<label_t *>(member) );
			break;
		}
		// �� => ����
		default:
			catf("%s%s = ignored (mptype = %d)",
				base.getIndent(), base.getName(),
				pStPrm->mptype
			);
			break;
	}
	return;
}

//------------------------------------------------
// 
//------------------------------------------------

//**********************************************************
//        �������֐�
//**********************************************************
//------------------------------------------------
// ���s��A������
//------------------------------------------------
void CVarinfoTree::cat_crlf( void )
{
	mpBuf->append( "\r\n" );
	return;
}

//------------------------------------------------
// �����t���������A������
//------------------------------------------------
void CVarinfoTree::catf( const char *format, ... )
{
	va_list   arglist;
	va_start( arglist, format );
	
	mpBuf->append( vstrf( format, arglist ) );
	cat_crlf();
	
	va_end( arglist );
	return;
}

#ifndef clhsp
//------------------------------------------------
// �f�o�b�O������𐶐�����
// 
// @prm pBuf : �Œ�ł� 1024 B ��K�v�Ƃ���
//------------------------------------------------
CString CVarinfoTree::getDbgString( vartype_t type, const void *pValue )
{
#ifndef HSPVAR_FLAG_VARIANT
	static const int HSPVAR_FLAG_VARIANT ( 7 );
#endif
	
	void *ptr ( const_cast<void *>(pValue) );
	
	switch ( type ) {
		case HSPVAR_FLAG_STR:     return CString( ptr_cast<char *>(ptr) );
	//	case HSPVAR_FLAG_STR:     return toStringLiteralFormat( ptr_cast<char *>(ptr) );
		case HSPVAR_FLAG_LABEL:   return strf("*label (0x%08X)",  address_cast( *ptr_cast<label_t *>(ptr)) );
		case HSPVAR_FLAG_COMOBJ:  return strf("comobj (0x%08X)",  address_cast( *ptr_cast<void **>(ptr) ));
		case HSPVAR_FLAG_VARIANT: return strf("variant (0x%08X)", address_cast( *ptr_cast<void **>(ptr)) );
		case HSPVAR_FLAG_DOUBLE:  return strf( "%.16f", *ptr_cast<double *>(ptr) );
		case HSPVAR_FLAG_INT:
		{
			int val ( *ptr_cast<int *>(ptr) );
			return strf( "%-10d (0x%08X)", val, val );
		}
		
		case HSPVAR_FLAG_STRUCT:
		{
#if clhsp
			ModInst *mv ( *ptr_cast<ModInst **>( ptr ) );
			if ( mv == NULL ) {
				return CString( "modinst (null)" );
				
			} else {
				STRUCTPRM *pStPrm ( &mdbginfo.ctx->mem_minfo[mv->id_minfo]  );
				STRUCTDAT *pStDat ( &mdbginfo.ctx->mem_finfo[pStPrm->subid] );

				return strf( "modinst (0x%08X) id%d(%s) ptr(%p) size(%d)",
					address_cast( mv ),
					pStPrm->subid,
					address_cast( &mdbginfo.ctx->mem_mds[pStDat->nameidx] ),
					mv->members,
					pStDat->size
				);
			}
#else
			FlexValue *fv ( ptr_cast<FlexValue *>( ptr ) );
			if ( fv->type == FLEXVAL_TYPE_NONE ) {
				return CString( "struct (empty)" ); 
			} else {
				return strf( "struct id%d ptr(0x%08X) size(%d) type(%d)",
					fv->customid, address_cast(fv->ptr), fv->size, fv->type
				); 
			}
#endif
		}
#if clhsp
		case HSPVAR_FLAG_VECTOR:
			return strf( "vector (0x%08X) ", address_cast( ptr_cast<Vector *>(ptr) ) );
		
		case HSPVAR_FLAG_REF:
		{
			bool       bExists ( false );
			Reference *pRef    ( ptr_cast<Reference *>( ptr ) );
			
			char sReferred[64 + 32];
			
			// �ÓI�ϐ�����T��
			for ( int i = 0; i < mdbginfo.ctx->hsphed->max_val; ++ i ) {
				if ( pRef->pval == &mdbginfo.ctx->mem_var[i] ) {
					strcpy_s( sReferred, mdbginfo.exinfo->HspFunc_varname(i) );
					bExists = true;
					break;
				}
			}
			
			if ( !bExists ) {
				return strf( "�Ȃɂ��ւ̎Q�� (%p [#%d])", pRef->pval, pRef->aptr );
				
			} else {
				if ( pRef->aptr ) {
					sprintf_s( sReferred, "%s [#%d]", sReferred, pRef->aptr );
				}
				return strf( "�ϐ� %s �ւ̎Q��", sReferred );
			}
		//*/
		}
#endif
		default:
			return strf( "Unknown<%s>: ptr(0x%08X)",
				mdbginfo.exinfo->HspFunc_getproc(type)->vartype_name,
				address_cast( ptr )
			);
	}
}

//------------------------------------------------
// ������𕶎��񃊃e�����̌`���ɕϊ�����
//------------------------------------------------
CString CVarinfoTree::toStringLiteralFormat( const char *src )
{
	char *buf = mdbginfo.exinfo->HspFunc_malloc( strlen(src) * 2 );
	uint iWrote( 0 );
	
	buf[iWrote ++] = '\"';
	
	for ( int i = 0; i < 0x400; ++ i ) {
		char c = src[i];
		
		// �G�X�P�[�v�E�V�[�P���X����������
		if ( c == '\0' ) {
			break;
			
		} else if ( c == '\\' || c == '\"' ) {
			buf[iWrote ++] = '\\';
			buf[iWrote ++] = c;
			
		} else if ( c == '\t' ) {
			buf[iWrote ++] = '\\';
			buf[iWrote ++] = 't';
			
		} else if ( c == '\r' || c == '\n' ) {
			buf[iWrote ++] = '\\';
			
			if ( c == '\r' && src[i + 1] == '\n' ) {	// CR + LF
				buf[iWrote ++] = 'n';
				i ++;
			} else {
				buf[iWrote ++] = 'r';
			}
			
		} else {
			buf[iWrote ++] = c;
		}
	}
	
	buf[iWrote ++] = '\"';
	buf[iWrote ++] = '\0';
	
	CString sResult ( buf );
	
	mdbginfo.exinfo->HspFunc_free( buf );
	
	return sResult;
}

#endif

//------------------------------------------------
// mptype �̕�����𓾂�
//------------------------------------------------
static const char *getMPTypeString( int mptype )
{
	switch ( mptype ) {
		case MPTYPE_NONE:    return "(unknown)";
		case MPTYPE_DNUM:    return "double";
		case MPTYPE_INUM:    return "int";
		
		case MPTYPE_STRING:
		case MPTYPE_LOCALSTRING: return "str";
		case MPTYPE_VAR:
		case MPTYPE_PVARPTR:				// #dllfunc
		case MPTYPE_SINGLEVAR:   return "var";
		case MPTYPE_ARRAYVAR:    return "array";
		case MPTYPE_LOCALVAR:    return "local";
		case MPTYPE_MODULEVAR:   return "modvar";
		case MPTYPE_IMODULEVAR:  return "modinit";
		case MPTYPE_TMODULEVAR:  return "modterm";
		
#ifdef clhsp
		case MPTYPE_LABEL:  return "label";
		case MPTYPE_STRUCT: return "struct";
	//	case MPTYPE_REF:    return "ref";
		case MPTYPE_VECTOR: return "vector";
		case MPTYPE_ANY:    return "any";
		case MPTYPE_FLEX:   return "...";		// flex
#endif
		
#if 0
		case MPTYPE_IOBJECTVAR:  return "comobj";
	//	case MPTYPE_LOCALWSTR:   return "";
	//	case MPTYPE_FLEXSPTR:    return "";
	//	case MPTYPE_FLEXWPTR:    return "";
		case MPTYPE_FLOAT:       return "float";
		case MPTYPE_PPVAL:       return "pval";
		case MPTYPE_PBMSCR:      return "bmscr";
		case MPTYPE_PTR_REFSTR:  return "prefstr";
		case MPTYPE_PTR_EXINFO:  return "pexinfo";
		case MPTYPE_PTR_DPMINFO: return "pdpminfo";
		case MPTYPE_NULLPTR:     return "nullptr";
		
		case MPTYPE_STRUCTTAG:   return "(structtag)";
#endif
		default: return "unknown";
	}
}

//**********************************************************
//    �ÓI�����o
//**********************************************************
const char *CVarinfoTree::stc_fmt_elemname[5] = {
	""         "\0%d%d%d",
	BracketIdxL "%d"         BracketIdxR "\0%d%d",
	BracketIdxL "%d, %d"     BracketIdxR "\0%d",
	BracketIdxL "%d, %d, %d" BracketIdxR,
	BracketIdxL "%d, %d, %d, 0"
};
