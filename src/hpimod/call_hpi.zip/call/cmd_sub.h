// Call - SubCommand header

#ifndef IG_CALL_SUB_COMMAND_H
#define IG_CALL_SUB_COMMAND_H

#include "hsp3plugin_custom.h"
#include "mod_argGetter.h"
#include "mod_makepval.h"

#include "CCall.h"
#include "CFunctor.h"
#include "cmd_call.h"

#include "CPrmInfo.h"

//################################################
//    Call �������֐�
//################################################
// �Ǝ��X�^�b�N
extern void  PushCallStack( CCall* pCall );
extern void   PopCallStack();
extern void  FreeCallStack();
extern CCall* TopCallStack();

// ���������X�g
extern void  DeclarePrmInfo( label_t lb, CPrmInfo&& prminfo );
extern const CPrmInfo& GetPrmInfo( label_t lb );
extern const CPrmInfo& GetPrmInfo( stdat_t pStDat );

// �ϊ��֐�
extern CPrmInfo CreatePrmInfo();
extern CPrmInfo CreatePrmInfo( stdat_t pStDat );

// ���̑�
extern stdat_t GetSTRUCTDAT( int deffid );
extern int GetPrmType( const char* s );

extern void* GetReferedPrmstk( stprm_t pStPrm);

//################################################
//    �������֐�
//################################################
template<class T>
bool numrg(const T& val, const T& min, const T& max)
{
	return (min <= val && val <= max);
}

// �����擾
extern int code_getaxcmd();
extern int code_getprmtype( int deftype = PRM_TYPE_NONE );
extern CFunctor            code_getfunctor();
extern CPrmInfo::prmlist_t code_get_prmlist();	// ���������X�g

#endif
