// �ϐ��֘A utility

#ifndef IG_MODULE_VARIABLE_UTILITY_H
#define IG_MODULE_VARIABLE_UTILITY_H

#include "hsp3plugin_custom.h"

namespace hpimod {

//##########################################################
//        �֐��錾
//##########################################################

// �ϐ����̎擾

// �ϐ��̍쐬
typedef void(*DimFunc_t)(PVal*, vartype_t, int, int, int, int, int);
extern int dimtypeEx( vartype_t vt, DimFunc_t fDim = nullptr );		// fDim = NULL => �ʏ�� dim ��p����

// APTR �֌W
extern APTR CreateAptrFromIndex(const PVal* pval, int idx[4]);
extern void GetIndexFromAptr   (const PVal* pval, APTR aptr, int ret[4]);

} // namespace hpimod

#endif
