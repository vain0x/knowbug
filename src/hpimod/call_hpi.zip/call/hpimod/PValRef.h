// PValRef

#ifndef IG_PVALREF_H
#define IG_PVALREF_H

#include "hsp3plugin_custom.h"

#ifdef _DEBUG
# define PVALREF_DBGCODE(...) //__VA_ARGS__
#else
# define PVALREF_DBGCODE(...) //
#endif

//------------------------------------------------
// (PVal*) with �Q�ƃJ�E���^
//------------------------------------------------
struct PValRef
{
	PVal pval;
	int cntRefed;			// �Q�ƃJ�E���^ (�A�N�ւ���ĂȂ��̂Œ��ӂ��邱��)
	int opt1, opt2;			// �\��
	
	PVALREF_DBGCODE(
		static int stt_counter;
		int id;
	)
	
	static PValRef* const MagicNull;
	
	//-----------------------------------------------
	// �֐�
	//-----------------------------------------------
	static PValRef* New( int vflag = HSPVAR_FLAG_INT );
	static void Delete( PValRef* pval );
	
	static void AddRef( PValRef* pval );
	static void Release( PValRef* pval );
	static PVal* AddRef( PVal* pval ) { PValRef::AddRef( (PValRef*)(pval) ); return pval; }
};

static       PVal*    AsPVal   (       PValRef* pval ) { return reinterpret_cast<      PVal*   >( pval ); }
static const PVal*    AsPVal   ( const PValRef* pval ) { return reinterpret_cast<const PVal*   >( pval ); }
static       PValRef* AsPValRef(       PVal*    pval ) { return reinterpret_cast<      PValRef*>( pval ); }
static const PValRef* AsPValRef( const PVal*    pval ) { return reinterpret_cast<const PValRef*>( pval ); }

static bool IsNull( const PValRef* pval ) { return ( pval == NULL || pval == PValRef::MagicNull ); }
static size_t Size( const PValRef* pval ) { return AsPVal(pval)->len[1]; }
static bool  Empty( const PValRef* pval ) { return AsPVal(pval)->len[1] == 0; }

static int Compare( const PValRef* lhs, const PValRef* rhs )
{
	// null?
	bool bNullLhs = IsNull(lhs);
	bool bNullRhs = IsNull(rhs);
	
	if ( bNullLhs || bNullRhs ) {
		return ( bNullLhs )
			? ( bNullRhs ? 0 : -1 )
			: 1;		// assert(IsNull(bNullRhs) == true)
	}

	// �v�f��
	
	return 0;
}

#endif
