// Call(Method) - Command header

#ifndef IG_CALL_METHOD_COMMAND_H
#define IG_CALL_METHOD_COMMAND_H

extern void Method_replace();
extern void Method_add();
extern void Method_cloneThis();

#endif
