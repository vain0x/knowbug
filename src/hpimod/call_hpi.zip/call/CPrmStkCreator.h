// prmstack �����N���X

#ifndef IG_CLASS_PARAMETER_STACK_H
#define IG_CLASS_PARAMETER_STACK_H

/**
@summary:
	prmstk �Ɠ����`���Ńf�[�^���i�[���鏈���̃C���^�[�t�F�[�X�ƂȂ�N���X�B
**/

#include "hsp3plugin.h"

//##############################################################################
//                �錾�� : CPrmStkCreator
//##############################################################################
class CPrmStkCreator
{
private:
	char*  mp;			// �X�^�b�N�̐擪�ւ̃|�C���^
	size_t musingSize;	// �g�p���ꂽ�T�C�Y
	size_t mbufSize;	// �m�ۍς݂̃T�C�Y
	
public:
	CPrmStkCreator( void* buf, size_t bufSize )
		: mp( reinterpret_cast<char*>( buf ) )
		, mbufSize( bufSize )
		, musingSize( 0 )
	{ }
	~CPrmStkCreator() { }
	
	// �擾
	void*  getptr()       const { return mp; }
	size_t getBufSize()   const { return mbufSize; }
	size_t getUsingSize() const { return musingSize; }
	
	// �i�[
	template<class T> void pushValue();		// �R�s�[�Ȃ�
	template<class T> void pushValue( const T& value );
	
	void pushPVal( PVal* pval, APTR aptr ) {
		pushValue( pval );
		pushValue( aptr );
	}
	void pushPVal( const MPVarData* pVarDat ) {
		pushPVal( pVarDat->pval, pVarDat->aptr );
	}
	void pushThismod( PVal* pval, APTR aptr, int idStDat ) {
		MPModVarData thismod = { MODVAR_MAGICCODE, idStDat, pval, aptr };
		pushValue( thismod );
	}
	
	PVal* pushLocal() {
		PVal* pval = reinterpret_cast<PVal*>( nextptr() );
		pushValue<PVal>();
		return pval;
	}
	
private:
	void needSize( size_t sizeAdditional ) {		// �g�p����T�C�Y�̐錾
		if ( mbufSize < (musingSize + sizeAdditional) ) {
			puterror( HSPERR_OUT_OF_MEMORY );
		}
	}
	
	void* nextptr() const { return mp + musingSize; }
	
private:
	// ����
	CPrmStkCreator( const CPrmStkCreator& obj );
	CPrmStkCreator& operator = ( const CPrmStkCreator& obj );
	
};

//------------------------------------------------
// �P���ɒl���v�b�V������
// 
// @ int, double, char*  �ȂǁA= �ŕ��ʉ\�Ȓl�B
//------------------------------------------------
template<class T>
void CPrmStkCreator::pushValue(const T& value)
{
	needSize( sizeof(T) );	// �K�v�ȃT�C�Y
	
	*reinterpret_cast<T*>(nextptr()) = value;	// �l�̕���
	
	musingSize += sizeof(T);
	return;
}

template<class T>
void CPrmStkCreator::pushValue()
{
	needSize( sizeof(T) );
	musingSize += sizeof(T);
	return;
}

#endif
