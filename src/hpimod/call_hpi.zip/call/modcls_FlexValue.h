// Call(ModCls) - FlexValue

// modcls �ɂ�������ꂽ struct �^�̎���
// �݊����̂��߁A�\���̎��̂� hsp3struct.h �ɂ���Ē�`����Ă�����̂𗬗p����B

// ���܂���S�Ȑ݌v�ł͂Ȃ��̂ŁA���L�֌W�ɒ��ӂ��Ďg���悤�Ɂc�c�B

#ifndef IG_MODCLS_FLEX_VALUE_H
#define IG_MODCLS_FLEX_VALUE_H

#include "hsp3struct.h"

extern FlexValue* code_get_modinst();
extern FlexValue* code_get_modinst( FlexValue* def );

extern void FlexValue_AddRef   ( FlexValue& self );
extern void FlexValue_Release  ( FlexValue& self );		// �f�X�g���N�^���ĂԂ�������Ȃ����Ƃɒ���
extern void FlexValue_DelRef   ( FlexValue& self );
extern void FlexValue_NullClear( FlexValue& self );

extern bool FlexValue_IsNull ( const FlexValue& self );
extern int  FlexValue_Counter( const FlexValue& self );
extern int  FlexValue_SubId  ( const FlexValue& self );
extern stdat_t     FlexValue_ModCls( const FlexValue& self );
extern const char* FlexValue_ClsName( const FlexValue& self );

extern void FlexValue_CtorWoCtorCalling( FlexValue& self, stdat_t modcls );
extern void FlexValue_Ctor( FlexValue& self, stdat_t modcls );
extern void FlexValue_Ctor( FlexValue& self, stdat_t modcls, PVal* pval, APTR aptr );
extern void FlexValue_Dtor( FlexValue& self );

extern void FlexValue_Copy( FlexValue& dst, FlexValue& src );
extern void FlexValue_Move( FlexValue& dst, FlexValue& src );

extern void FlexValue_AddRefTmp ( FlexValue& self );
extern void FlexValue_ReleaseTmp( FlexValue& self );
extern bool FlexValue_IsTmp( const FlexValue& self );

extern bool FlexValueEx_Valid( const FlexValue& self );

static const char* ModCls_Name( stdat_t modcls )
{
	return ( modcls ? &ctx->mem_mds[ modcls->nameidx ] : "#nullmod" );
}

//------------------------------------------------
// FlexValue �z���_�[
//------------------------------------------------
class FlexValueHolder
{
	FlexValue& mOwner;
	FlexValue mFv;
	
public:
	FlexValueHolder( FlexValue& fv )
		: mOwner(fv), mFv(fv)
	{
		FlexValue_AddRef( mFv );
	}
	~FlexValueHolder()
	{
		FlexValue_Move( mOwner, mFv );
	}
	
	const FlexValue& get() const { return mFv; }
	FlexValue& get() { return mFv; }
	operator const FlexValue&() const { return mFv; }
	
	      FlexValue* operator &()       { return &mFv; }
	const FlexValue* operator &() const { return &mFv; }
	
private:
	FlexValueHolder& operator = ( const FlexValueHolder& );
};

#endif
